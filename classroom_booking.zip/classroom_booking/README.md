# Classroom Resource Booking (StudentLife Hack — Project #22)

A beginner-friendly, fault-tolerant Python application for recording classroom and lab resource booking requests, detecting schedule conflicts in real time, persisting records to JSON & CSV, and generating executive analytics and audit exports.

## Features

- **Interactive Terminal Interface**: Branded menu-driven CLI with ANSI formatting, guided workflows, and fixed-width paginated tables.
- **Defensive Input Validation**: Strict sanitization, calendar date checks, 24-hour campus operating hours (`07:00`–`22:00`), duration bounds (`30`–`480` min), room capacity checks, and email validation.
- **Schedule Conflict Engine**: Overlap detection (`start_a < end_b and start_b < end_a`) across active (`Pending` & `Approved`) bookings, with automatic suggestions for alternative rooms and free time slots.
- **JSON & CSV Local Persistence**: Synchronized `data/bookings.json`, `data/bookings.csv`, and `data/rooms.json` with atomic writes and automatic corruption backup & recovery.
- **Search & Executive Analytics**: Multi-criteria search, room utilization breakdown, peak hours, and automated threshold alerts (`CRITICAL` conflicts, `HIGH` overdue/urgent pending requests, `MEDIUM` near-capacity `>=90%`, `>4h` durations, and campus holidays).
- **Stretch Features Included**:
  - Multi-format exports: Markdown summary (`.md`), plain-text audit log (`.txt`), enriched CSV (`.csv`), interactive HTML dashboard (`.html`), and optional Matplotlib PNG chart.
  - Bulk legacy CSV import (`data/sample_legacy_import.csv`) with row-by-row validation and audit logging.
  - Optional Tkinter GUI (`python main.py --gui` or menu option `9`).
  - Optional remote holiday lookup (`requests`) with offline cache fallback (`data/holidays_cache.json`).

## Quick Start

Requires **Python 3.10+** (zero required third-party dependencies).

```bash
# Run interactive terminal app
python main.py

# Print executive summary directly
python main.py --summary

# Launch optional Tkinter GUI
python main.py --gui

# Generate standalone interactive HTML dashboard (dashboard.html)
python main.py --html
```

## Project Structure

```text
classroom_booking/
├── main.py                        # Convenience CLI/GUI launcher
├── dashboard.html                 # Interactive HTML executive dashboard & searchable register
├── pyproject.toml                 # Package metadata & console script entry point
├── requirements.txt               # Optional dependencies (matplotlib, requests)
├── build_package.py               # Runs tests and builds classroom_booking_prototype.zip
├── data/
│   ├── rooms.json                 # 8 campus classrooms, labs, and halls
│   ├── bookings.json              # 40 seeded booking records (JSON)
│   ├── bookings.csv               # 40 seeded booking records (CSV)
│   ├── holidays_cache.json        # Offline campus holiday fallback cache
│   └── sample_legacy_import.csv   # Mixed valid/invalid CSV for bulk import demo
├── src/classroom_booking/
│   ├── models.py                  # Room & BookingRequest dataclasses
│   ├── validators.py              # Input validators & interactive prompt wrappers
│   ├── storage.py                 # Atomic JSON/CSV persistence & corruption recovery
│   ├── engine.py                  # Conflict detector, alternatives & threshold alerts
│   ├── analytics.py               # Executive summary & optional Matplotlib chart
│   ├── exporter.py                # Markdown, TXT audit log, CSV & HTML report generator
│   ├── importer.py                # Row-by-row bulk CSV importer
│   ├── gui.py                     # Optional Tkinter graphical UI
│   ├── cli.py                     # Interactive terminal UI
│   └── seed_data.py               # 40-entry realistic dataset generator
└── tests/
    └── test_classroom_booking.py  # Unit & integration test suite
```

## Hackathon Demo Walkthrough

1. Launch `python main.py` to showcase the branded welcome screen, live conflict badge, and 40 seeded records.
2. Choose **[1] Record New Booking Request** and intentionally enter an invalid date (`2026-02-30`) or over-capacity attendee count to show defensive validation catching errors without crashing.
3. Submit an overlapping slot (e.g., `CR-101` on `2026-11-25` at `09:30`–`10:30`) to demonstrate real-time conflict detection and alternative room/slot suggestions.
4. Choose **[5] Executive Summary & Threshold Alerts** to inspect room utilization, peak hours, and flagged `CRITICAL`/`HIGH`/`MEDIUM` alerts.
5. Choose **[6] Export Reports** to generate Markdown, audit log, and CSV deliverables in `exports/`.
6. Choose **[7] Bulk Import Legacy CSV** with `data/sample_legacy_import.csv` to show row-by-row validation and audit logging.
7. Exit and relaunch `python main.py` to verify persistence across restarts.

## Running Tests & Building the Zip Package

```bash
python -m unittest discover -s tests -v
python build_package.py
```
