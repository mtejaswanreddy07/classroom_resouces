"""Executive summary analytics and optional Matplotlib visualization."""

from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

from .engine import BookingEngine
from .models import VALID_STATUSES


def generate_executive_summary(engine: BookingEngine) -> dict[str, Any]:
    """Compute totals, averages, utilization metrics, and schedule trends."""
    bookings = engine.bookings
    total = len(bookings)
    status_counts = {status: 0 for status in VALID_STATUSES}
    for b in bookings:
        status_counts[b.status] = status_counts.get(b.status, 0) + 1

    active = [b for b in bookings if b.is_active]
    conflicts = engine.find_all_schedule_conflicts()
    warnings = engine.get_threshold_warnings()

    total_hours = round(sum(b.duration_hours() for b in bookings), 2)
    active_hours = round(sum(b.duration_hours() for b in active), 2)
    avg_duration = round(total_hours / total, 2) if total else 0.0
    avg_attendees = round(sum(b.attendees for b in bookings) / total, 1) if total else 0.0

    fill_ratios: list[float] = []
    for b in active:
        room = engine.rooms_by_id.get(b.room_id)
        if room and room.capacity > 0:
            fill_ratios.append((b.attendees / room.capacity) * 100.0)
    avg_utilization = round(sum(fill_ratios) / len(fill_ratios), 1) if fill_ratios else 0.0

    decided = status_counts["Approved"] + status_counts["Rejected"]
    approval_rate = round((status_counts["Approved"] / decided) * 100.0, 1) if decided else 0.0

    # Breakdown by resource type
    type_buckets: dict[str, list[Any]] = defaultdict(list)
    for b in bookings:
        type_buckets[b.resource_type].append(b)
    by_resource_type = []
    for r_type, items in sorted(type_buckets.items(), key=lambda kv: (-len(kv[1]), kv[0])):
        by_resource_type.append(
            {
                "resource_type": r_type,
                "count": len(items),
                "active_count": sum(1 for x in items if x.is_active),
                "hours": round(sum(x.duration_hours() for x in items if x.is_active), 2),
                "avg_attendees": round(sum(x.attendees for x in items) / len(items), 1),
            }
        )

    # Breakdown by room
    room_buckets: dict[str, list[Any]] = defaultdict(list)
    for b in active:
        room_buckets[b.room_id].append(b)
    by_room = []
    for room in engine.rooms:
        items = room_buckets.get(room.room_id, [])
        avg_fill = (
            round(sum((x.attendees / room.capacity) * 100.0 for x in items) / len(items), 1)
            if items and room.capacity > 0
            else 0.0
        )
        by_room.append(
            {
                "room_id": room.room_id,
                "name": room.name,
                "resource_type": room.resource_type,
                "capacity": room.capacity,
                "active_count": len(items),
                "active_hours": round(sum(x.duration_hours() for x in items), 2),
                "avg_fill_pct": avg_fill,
            }
        )
    by_room.sort(key=lambda r: (-r["active_hours"], r["room_id"]))

    dept_counter = Counter(b.department for b in bookings)
    hour_counter = Counter(f"{b.start_time[:2]}:00" for b in active)
    date_counter = Counter(b.date for b in active)

    return {
        "total_bookings": total,
        "active_bookings": len(active),
        "status_counts": status_counts,
        "approval_rate_pct": approval_rate,
        "total_hours": total_hours,
        "active_hours_booked": active_hours,
        "avg_duration_hours": avg_duration,
        "avg_attendees": avg_attendees,
        "avg_room_utilization_pct": avg_utilization,
        "conflict_count": len(conflicts),
        "warning_count": len(warnings),
        "by_resource_type": by_resource_type,
        "by_room": by_room,
        "top_departments": dept_counter.most_common(5),
        "peak_hours": hour_counter.most_common(5),
        "busiest_dates": date_counter.most_common(5),
    }


def export_summary_chart(summary: dict[str, Any], output_path: Path) -> tuple[bool, str]:
    """Generate an optional PNG summary chart using Matplotlib if installed."""
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return False, "Matplotlib is not installed (optional); skipped PNG chart generation."

    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))

    # Left: Bookings by Status
    statuses = list(summary["status_counts"].keys())
    counts = [summary["status_counts"][s] for s in statuses]
    colors = ["#f59e0b", "#10b981", "#ef4444", "#6b7280"]
    axes[0].bar(statuses, counts, color=colors[: len(statuses)])
    axes[0].set_title("Bookings by Status")
    axes[0].set_ylabel("Count")

    # Right: Active Hours by Room
    rooms = [r["room_id"] for r in summary["by_room"]]
    hours = [r["active_hours"] for r in summary["by_room"]]
    axes[1].barh(rooms[::-1], hours[::-1], color="#3b82f6")
    axes[1].set_title("Active Booked Hours by Room")
    axes[1].set_xlabel("Hours")

    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return True, f"Saved analytics chart to {output_path}"
