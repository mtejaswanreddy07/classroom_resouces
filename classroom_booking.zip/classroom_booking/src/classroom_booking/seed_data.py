"""Seed dataset generator with 40 realistic classroom/lab booking records."""

from __future__ import annotations

from .models import BookingRequest, Room

DEFAULT_HOLIDAYS: dict[str, str] = {
    "2026-01-01": "New Year's Day",
    "2026-01-26": "Republic Day (Campus Closed)",
    "2026-05-01": "Labor Day",
    "2026-08-15": "Independence Day",
    "2026-10-02": "Gandhi Jayanti",
    "2026-11-08": "Diwali Break",
    "2026-12-25": "Winter Recess / Christmas",
}


def get_default_rooms() -> list[Room]:
    """Return a realistic campus catalog of classrooms, labs, and halls."""
    return [
        Room(
            room_id="CR-101",
            name="Lecture Hall 101",
            resource_type="Classroom",
            building="Main Academic Block",
            capacity=60,
            equipment=["Projector", "Whiteboard", "Lecture Capture Mic"],
        ),
        Room(
            room_id="CR-102",
            name="Tutorial Room 102",
            resource_type="Classroom",
            building="Main Academic Block",
            capacity=40,
            equipment=["Smart TV", "Whiteboard"],
        ),
        Room(
            room_id="CR-205",
            name="Active Learning Studio 205",
            resource_type="Classroom",
            building="Innovation Wing",
            capacity=45,
            equipment=["Dual Projectors", "Modular Tables", "Whiteboard"],
        ),
        Room(
            room_id="LAB-201",
            name="Systems & Networks Lab",
            resource_type="Computer Lab",
            building="CS & Engineering Block",
            capacity=36,
            equipment=["36 Linux Workstations", "Projector", "Gigabit Switch"],
        ),
        Room(
            room_id="LAB-204",
            name="AI & Data Science Lab",
            resource_type="Computer Lab",
            building="CS & Engineering Block",
            capacity=30,
            equipment=["30 GPU Workstations", "Smart Board", "AC"],
        ),
        Room(
            room_id="LAB-302",
            name="Embedded & Robotics Lab",
            resource_type="Science Lab",
            building="Applied Sciences Block",
            capacity=24,
            equipment=["Oscilloscopes", "Soldering Stations", "3D Printers"],
        ),
        Room(
            room_id="SEM-110",
            name="Faculty Seminar Room 110",
            resource_type="Seminar Hall",
            building="Administrative Annex",
            capacity=80,
            equipment=["4K Projector", "PA System", "Video Conferencing"],
        ),
        Room(
            room_id="AUD-01",
            name="Dr. Kalam Central Auditorium",
            resource_type="Auditorium",
            building="Student Center",
            capacity=250,
            equipment=["Stage Lighting", "Dual Screens", "Wireless Mics", "Livestream Rig"],
        ),
    ]


def get_default_bookings() -> list[BookingRequest]:
    """Return 40 realistic booking records covering normal, boundary, and edge cases."""
    raw_rows = [
        # --- Normal Approved Bookings ---
        ("BK-1001", "CR-101", "Classroom", "CS101 Intro to Python Lecture", "Dr. Ananya Rao", "ananya.rao@campus.edu", "Computer Science", "2026-11-25", "09:00", "10:30", 52, "Approved", "Normal", "2026-11-10T09:15:00", "Weekly core lecture"),
        ("BK-1002", "CR-101", "Classroom", "MA201 Linear Algebra", "Prof. Vikram Sethi", "vikram.sethi@campus.edu", "Mathematics", "2026-11-25", "10:30", "12:00", 58, "Approved", "Normal", "2026-11-11T11:00:00", "Back-to-back boundary slot"),
        ("BK-1003", "LAB-201", "Computer Lab", "OS Kernel Practicum", "Dr. Meera Nair", "meera.nair@campus.edu", "Computer Science", "2026-11-25", "14:00", "16:30", 34, "Approved", "High", "2026-11-12T10:20:00", "Needs root VM image"),
        ("BK-1004", "LAB-204", "Computer Lab", "Deep Learning Studio", "Dr. Arjun Menon", "arjun.menon@campus.edu", "AI & Data Science", "2026-11-26", "09:00", "11:30", 30, "Approved", "High", "2026-11-12T14:45:00", "Exact max capacity (30/30)"),
        ("BK-1005", "CR-102", "Classroom", "Technical Writing Workshop", "Prof. Elena Gomes", "elena.gomes@campus.edu", "Humanities", "2026-11-26", "13:00", "13:30", 18, "Approved", "Normal", "2026-11-13T09:05:00", "Minimum 30-min boundary briefing"),
        ("BK-1006", "SEM-110", "Seminar Hall", "Campus Sustainability Panel", "Rohan Kulkarni", "rohan.k@campus.edu", "Student Council", "2026-11-26", "16:00", "18:00", 74, "Approved", "High", "2026-11-13T16:10:00", "Near-capacity (92.5%)"),
        ("BK-1007", "AUD-01", "Auditorium", "StudentLife Hackathon Kickoff", "Priya Sharma", "priya.sharma@campus.edu", "ACM Student Chapter", "2026-11-27", "09:00", "14:30", 230, "Approved", "Urgent", "2026-11-14T12:00:00", "Long duration >4h & near-capacity"),
        ("BK-1008", "LAB-302", "Science Lab", "Autonomous Rover Testing", "Dr. Karthik Iyer", "karthik.iyer@campus.edu", "Robotics Club", "2026-11-27", "15:00", "18:00", 22, "Approved", "Normal", "2026-11-14T15:30:00", "Near-capacity safety check"),
        ("BK-1009", "CR-205", "Classroom", "Design Thinking Sprint", "Prof. Neha Kapoor", "neha.kapoor@campus.edu", "Design", "2026-11-28", "10:00", "12:30", 36, "Approved", "Normal", "2026-11-15T08:40:00", "Modular seating layout"),
        ("BK-1010", "CR-101", "Classroom", "Early Morning Olympiad Prep", "Dr. Vikram Sethi", "vikram.sethi@campus.edu", "Mathematics", "2026-11-28", "07:00", "08:30", 25, "Approved", "Normal", "2026-11-15T09:00:00", "Opening hour 07:00 boundary"),
        ("BK-1011", "LAB-201", "Computer Lab", "Evening Coding Bootcamp", "Siddharth Verma", "siddharth.v@campus.edu", "Placement Cell", "2026-11-28", "20:00", "22:00", 32, "Approved", "Normal", "2026-11-15T17:20:00", "Closing hour 22:00 boundary"),
        ("BK-1012", "SEM-110", "Seminar Hall", "Industry Guest Talk: FinTech", "Dr. Sanjay Gupta", "sanjay.gupta@campus.edu", "Management", "2026-11-29", "11:00", "13:00", 65, "Approved", "High", "2026-11-16T10:00:00", "Livestream recording requested"),
        ("BK-1013", "CR-102", "Classroom", "Discrete Math Recitation", "Aditi Joshi", "aditi.joshi@campus.edu", "Mathematics", "2026-11-30", "09:00", "10:00", 28, "Approved", "Normal", "2026-11-16T13:15:00", "TA office hours"),
        ("BK-1014", "LAB-204", "Computer Lab", "Computer Vision Lab", "Dr. Arjun Menon", "arjun.menon@campus.edu", "AI & Data Science", "2026-11-30", "14:00", "16:00", 27, "Approved", "Normal", "2026-11-17T09:45:00", "GPU cluster reservation"),
        ("BK-1015", "CR-205", "Classroom", "Entrepreneurship Clinic", "Prof. Neha Kapoor", "neha.kapoor@campus.edu", "Management", "2026-12-01", "11:00", "13:00", 40, "Approved", "Normal", "2026-11-17T11:30:00", "Team pitch practice"),
        ("BK-1016", "AUD-01", "Auditorium", "Annual Cultural Rehearsal", "Anjali Menon", "anjali.m@campus.edu", "Cultural Committee", "2026-12-01", "17:00", "21:00", 180, "Approved", "Normal", "2026-11-17T14:00:00", "Stage lighting setup"),
        ("BK-1017", "LAB-302", "Science Lab", "IoT Sensor Calibration", "Dr. Karthik Iyer", "karthik.iyer@campus.edu", "Electronics", "2026-12-02", "09:30", "12:00", 20, "Approved", "Normal", "2026-11-18T08:55:00", "Bench power supplies needed"),
        ("BK-1018", "CR-101", "Classroom", "Algorithms Mock Exam", "Dr. Ananya Rao", "ananya.rao@campus.edu", "Computer Science", "2026-12-02", "14:00", "16:00", 60, "Approved", "High", "2026-11-18T10:15:00", "Exact max capacity (60/60)"),
        ("BK-1019", "SEM-110", "Seminar Hall", "PhD Thesis Defense: Robotics", "Dr. Suresh Patel", "suresh.patel@campus.edu", "Mechanical Eng", "2026-12-03", "10:00", "12:00", 45, "Approved", "High", "2026-11-18T15:00:00", "External examiners online"),
        ("BK-1020", "CR-102", "Classroom", "French Language Club", "Claire Moreau", "claire.m@campus.edu", "Humanities", "2026-12-03", "16:30", "18:00", 24, "Approved", "Normal", "2026-11-19T09:10:00", "Audio playback required"),
        ("BK-1021", "LAB-201", "Computer Lab", "Cybersecurity CTF Practice", "Nikhil Verma", "nikhil.v@campus.edu", "InfoSec Club", "2026-12-04", "15:00", "19:30", 35, "Approved", "High", "2026-11-19T12:20:00", "Long duration >4h & near-capacity"),
        ("BK-1022", "CR-205", "Classroom", "UI/UX Peer Critique", "Tanvi Deshmukh", "tanvi.d@campus.edu", "Design", "2026-12-04", "10:00", "11:30", 30, "Approved", "Normal", "2026-11-19T16:45:00", "Sticky notes & whiteboards"),
        ("BK-1023", "LAB-204", "Computer Lab", "NLP Transformer Workshop", "Dr. Arjun Menon", "arjun.menon@campus.edu", "AI & Data Science", "2026-12-05", "10:00", "13:00", 28, "Approved", "Normal", "2026-11-20T09:00:00", "Near-capacity (93%)"),
        ("BK-1024", "AUD-01", "Auditorium", "Winter Convocation Briefing", "Registrar Office", "registrar@campus.edu", "Administration", "2026-12-06", "09:00", "12:00", 240, "Approved", "Urgent", "2026-11-20T11:10:00", "Near-capacity (96%)"),
        ("BK-1025", "CR-101", "Classroom", "Database Systems Review", "Dr. Meera Nair", "meera.nair@campus.edu", "Computer Science", "2026-12-07", "11:00", "12:30", 48, "Approved", "Normal", "2026-11-20T14:25:00", "Final exam prep"),

        # --- Pending Requests (including overdue/urgent & 1 intentional legacy conflict for demo audit) ---
        ("BK-1026", "CR-102", "Classroom", "Debate Society Tryouts", "Kabir Malhotra", "kabir.m@campus.edu", "Debate Club", "2026-11-24", "17:00", "19:00", 35, "Pending", "Normal", "2026-11-18T18:00:00", "Overdue unreviewed pending request"),
        ("BK-1027", "LAB-302", "Science Lab", "Drone Flight Controller Test", "Ishaan Roy", "ishaan.roy@campus.edu", "Aero Club", "2026-11-26", "10:00", "12:00", 16, "Pending", "Urgent", "2026-11-24T09:30:00", "Urgent pending within 48h"),
        ("BK-1028", "CR-101", "Classroom", "Data Structures Extra Tutorial", "Prof. Rahul Bose", "rahul.bose@campus.edu", "Computer Science", "2026-11-25", "09:30", "11:00", 42, "Pending", "High", "2026-11-21T10:00:00", "Imported paper-form request overlapping BK-1001/BK-1002"),
        ("BK-1029", "SEM-110", "Seminar Hall", "Alumni Mentorship Mixer", "Sneha Reddy", "sneha.r@campus.edu", "Alumni Relations", "2026-12-08", "15:00", "17:30", 72, "Pending", "Normal", "2026-11-21T16:15:00", "Awaiting AV approval"),
        ("BK-1030", "LAB-201", "Computer Lab", "Cloud DevOps Lab Exam", "Dr. Meera Nair", "meera.nair@campus.edu", "Computer Science", "2026-12-09", "09:00", "12:00", 36, "Pending", "High", "2026-11-22T09:40:00", "Exact max capacity (36/36)"),
        ("BK-1031", "CR-205", "Classroom", "Product Management Case Study", "Devika Nair", "devika.n@campus.edu", "Management", "2026-12-10", "14:00", "16:00", 38, "Pending", "Normal", "2026-11-22T14:50:00", "Needs breakout tables"),
        ("BK-1032", "LAB-204", "Computer Lab", "Bioinformatics Sequencing Run", "Dr. Kavita Rao", "kavita.rao@campus.edu", "Biotechnology", "2026-12-11", "08:30", "13:30", 24, "Pending", "High", "2026-11-23T11:05:00", "Long duration 5h simulation"),
        ("BK-1033", "AUD-01", "Auditorium", "TEDx Campus Dry Run", "Aarav Mehta", "aarav.m@campus.edu", "TEDx Club", "2026-12-12", "13:00", "18:30", 210, "Pending", "High", "2026-11-23T15:30:00", "Long duration 5.5h rehearsal"),
        ("BK-1034", "CR-102", "Classroom", "Statistics Help Desk", "Prof. Vikram Sethi", "vikram.sethi@campus.edu", "Mathematics", "2026-12-13", "10:00", "11:30", 22, "Pending", "Normal", "2026-11-24T08:45:00", "Pre-finals clinic"),

        # --- Rejected & Cancelled (Do not block active schedule slots) ---
        ("BK-1035", "AUD-01", "Auditorium", "Gaming LAN Night", "Varun Gill", "varun.g@campus.edu", "Esports Club", "2026-11-27", "10:00", "14:00", 120, "Rejected", "Normal", "2026-11-16T19:00:00", "Rejected due to conflict with BK-1007"),
        ("BK-1036", "LAB-201", "Computer Lab", "Freshers Orientation Lab", "Priya Sharma", "priya.sharma@campus.edu", "Student Council", "2026-11-25", "14:30", "16:00", 30, "Rejected", "Normal", "2026-11-17T12:10:00", "Rejected due to conflict with BK-1003"),
        ("BK-1037", "CR-101", "Classroom", "Guest Lecture: Quantum Info", "Dr. R. Subramanian", "r.sub@campus.edu", "Physics", "2026-12-02", "14:00", "15:30", 50, "Cancelled", "Normal", "2026-11-15T10:30:00", "Speaker rescheduled to Jan"),
        ("BK-1038", "SEM-110", "Seminar Hall", "Budget Review Meeting", "Finance Team", "finance@campus.edu", "Administration", "2026-11-29", "11:30", "12:30", 25, "Cancelled", "Normal", "2026-11-18T11:20:00", "Moved online"),
        ("BK-1039", "LAB-302", "Science Lab", "Chemistry Titration Demo", "Dr. Maya Sen", "maya.sen@campus.edu", "Chemistry", "2026-12-04", "10:00", "12:00", 18, "Cancelled", "Normal", "2026-11-19T14:00:00", "Moved to Wet Lab B"),
        ("BK-1040", "CR-205", "Classroom", "Photography Club Exhibition", "Zoya Khan", "zoya.k@campus.edu", "Media Club", "2026-12-05", "14:00", "17:00", 40, "Approved", "Normal", "2026-11-21T13:45:00", "Weekend showcase"),
    ]

    return [
        BookingRequest(
            booking_id=r[0],
            room_id=r[1],
            resource_type=r[2],
            title=r[3],
            requester_name=r[4],
            requester_email=r[5],
            department=r[6],
            date=r[7],
            start_time=r[8],
            end_time=r[9],
            attendees=r[10],
            status=r[11],
            priority=r[12],
            created_at=r[13],
            notes=r[14],
        )
        for r in raw_rows
    ]
