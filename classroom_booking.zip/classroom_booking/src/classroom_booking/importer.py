"""Bulk CSV dataset importer with row-by-row validation and audit logging."""

from __future__ import annotations

import csv
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from .engine import BookingEngine, ScheduleConflictError
from .validators import ValidationError


@dataclass
class ImportResult:
    """Summary of a bulk CSV import execution."""

    total_rows: int = 0
    imported_count: int = 0
    skipped_count: int = 0
    warnings_count: int = 0
    audit_log_path: Path | None = None
    row_logs: list[str] = field(default_factory=list)


def import_csv_dataset(
    engine: BookingEngine,
    csv_path: Path,
    audit_dir: Path,
) -> ImportResult:
    """Ingest a CSV dataset row by row, logging accepted, warned, and rejected rows."""
    source = Path(csv_path)
    if not source.exists() or not source.is_file():
        raise FileNotFoundError(f"Import file not found: {source}")

    result = ImportResult()
    required_cols = {
        "room_id",
        "title",
        "requester_name",
        "requester_email",
        "department",
        "date",
        "start_time",
        "end_time",
        "attendees",
    }

    with source.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames:
            raise ValidationError("CSV file is empty or missing a header row.")
        missing_cols = sorted(required_cols - set(reader.fieldnames))
        if missing_cols:
            raise ValidationError(
                f"CSV missing required columns: {', '.join(missing_cols)}"
            )

        for row_num, raw_row in enumerate(reader, start=2):
            result.total_rows += 1
            payload = {k: (v.strip() if isinstance(v, str) else v) for k, v in raw_row.items()}
            try:
                booking, warnings = engine.create_booking(payload, allow_conflict=False)
                result.imported_count += 1
                if warnings:
                    result.warnings_count += len(warnings)
                    result.row_logs.append(
                        f"Row {row_num:>3} [IMPORTED+WARN] {booking.booking_id}: "
                        + " | ".join(warnings)
                    )
                else:
                    result.row_logs.append(
                        f"Row {row_num:>3} [IMPORTED]      {booking.booking_id} "
                        f"({booking.room_id} {booking.date} {booking.start_time}-{booking.end_time})"
                    )
            except ScheduleConflictError as exc:
                result.skipped_count += 1
                result.row_logs.append(f"Row {row_num:>3} [CONFLICT]      {exc}")
            except ValidationError as exc:
                result.skipped_count += 1
                result.row_logs.append(f"Row {row_num:>3} [INVALID]       {exc}")

    audit_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    audit_path = audit_dir / f"import_audit_{stamp}.txt"
    header = [
        "BULK CSV IMPORT AUDIT LOG",
        f"Source File : {source}",
        f"Timestamp   : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"Total Rows  : {result.total_rows}",
        f"Imported    : {result.imported_count}",
        f"Skipped     : {result.skipped_count}",
        f"Warnings    : {result.warnings_count}",
        "-" * 72,
    ]
    audit_path.write_text("\n".join(header + result.row_logs) + "\n", encoding="utf-8")
    result.audit_log_path = audit_path
    return result
