"""Core business logic engine for booking management and conflict detection."""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any

from .models import (
    LONG_DURATION_THRESHOLD_MINUTES,
    NEAR_CAPACITY_RATIO,
    OPERATING_END_HOUR,
    OPERATING_START_HOUR,
    VALID_STATUSES,
    BookingRequest,
    Room,
)
from .storage import DataStore
from .validators import (
    ValidationError,
    validate_booking_payload,
    validate_choice,
    validate_date,
    validate_room_id,
    validate_time_range,
)


class ScheduleConflictError(Exception):
    """Raised when a booking collides with an existing active schedule slot."""

    def __init__(
        self,
        message: str,
        conflicts: list[BookingRequest],
        alternative_rooms: list[Room] | None = None,
        alternative_slots: list[tuple[str, str]] | None = None,
    ) -> None:
        super().__init__(message)
        self.conflicts = conflicts
        self.alternative_rooms = alternative_rooms or []
        self.alternative_slots = alternative_slots or []


def _to_minutes(hhmm: str) -> int:
    """Convert HH:MM string to minutes since midnight."""
    parts = hhmm.split(":")
    return int(parts[0]) * 60 + int(parts[1])


def _from_minutes(total: int) -> str:
    """Convert minutes since midnight to HH:MM string."""
    return f"{total // 60:02d}:{total % 60:02d}"


def times_overlap(start_a: str, end_a: str, start_b: str, end_b: str) -> bool:
    """Return True when two [start, end) time intervals overlap."""
    sa, ea = _to_minutes(start_a), _to_minutes(end_a)
    sb, eb = _to_minutes(start_b), _to_minutes(end_b)
    return sa < eb and sb < ea


class BookingEngine:
    """Coordinates room catalog, booking records, conflict detection, and queries."""

    def __init__(self, store: DataStore) -> None:
        self.store = store
        self.rooms: list[Room] = self.store.load_rooms()
        self.rooms_by_id: dict[str, Room] = {r.room_id: r for r in self.rooms}
        self.bookings: list[BookingRequest] = self.store.load_bookings()
        self.holidays: dict[str, str] = self.store.load_holidays()

    def reload(self) -> None:
        """Reload state from disk."""
        self.rooms = self.store.load_rooms()
        self.rooms_by_id = {r.room_id: r for r in self.rooms}
        self.bookings = self.store.load_bookings()
        self.holidays = self.store.load_holidays()

    def save(self) -> None:
        """Persist current bookings to JSON and CSV."""
        self.store.save_bookings(self.bookings)

    def next_booking_id(self) -> str:
        """Generate the next sequential BK-XXXX identifier."""
        max_num = 1000
        for b in self.bookings:
            if b.booking_id.startswith("BK-"):
                tail = b.booking_id[3:]
                if tail.isdigit():
                    max_num = max(max_num, int(tail))
        return f"BK-{max_num + 1}"

    def get_booking(self, booking_id: str) -> BookingRequest | None:
        """Retrieve a booking by ID (case-insensitive)."""
        target = booking_id.strip().upper()
        for b in self.bookings:
            if b.booking_id == target:
                return b
        return None

    def detect_conflicts(
        self,
        room_id: str,
        date: str,
        start_time: str,
        end_time: str,
        exclude_booking_id: str | None = None,
        statuses: frozenset[str] | None = None,
    ) -> list[BookingRequest]:
        """Find all active bookings on the same room/date that overlap the given window."""
        target_room = room_id.strip().upper()
        exclude = exclude_booking_id.strip().upper() if exclude_booking_id else None
        matches: list[BookingRequest] = []
        for existing in self.bookings:
            if exclude and existing.booking_id == exclude:
                continue
            if statuses is not None:
                if existing.status not in statuses:
                    continue
            elif not existing.is_active:
                continue
            if existing.room_id == target_room and existing.date == date:
                if times_overlap(start_time, end_time, existing.start_time, existing.end_time):
                    matches.append(existing)
        return sorted(matches, key=lambda b: b.start_time)

    def suggest_alternative_rooms(
        self,
        date: str,
        start_time: str,
        end_time: str,
        attendees: int,
        preferred_type: str | None = None,
        exclude_room_id: str | None = None,
    ) -> list[Room]:
        """Return conflict-free rooms that fit the attendee count."""
        candidates: list[Room] = []
        for room in self.rooms:
            if exclude_room_id and room.room_id == exclude_room_id:
                continue
            if room.capacity < attendees:
                continue
            if not self.detect_conflicts(room.room_id, date, start_time, end_time):
                candidates.append(room)

        candidates.sort(
            key=lambda r: (
                0 if preferred_type and r.resource_type == preferred_type else 1,
                r.capacity - attendees,
                r.room_id,
            )
        )
        return candidates

    def find_available_slots(
        self,
        room_id: str,
        date: str,
        duration_minutes: int,
        step_minutes: int = 30,
    ) -> list[tuple[str, str]]:
        """Scan campus operating hours to find available time slots on a room/date."""
        day_bookings = [
            b
            for b in self.bookings
            if b.room_id == room_id.upper() and b.date == date and b.is_active
        ]
        start_limit = OPERATING_START_HOUR * 60
        end_limit = OPERATING_END_HOUR * 60
        free_slots: list[tuple[str, str]] = []
        cursor = start_limit
        while cursor + duration_minutes <= end_limit:
            cand_start = _from_minutes(cursor)
            cand_end = _from_minutes(cursor + duration_minutes)
            overlaps = any(
                times_overlap(cand_start, cand_end, b.start_time, b.end_time)
                for b in day_bookings
            )
            if not overlaps:
                free_slots.append((cand_start, cand_end))
                cursor += duration_minutes
            else:
                cursor += step_minutes
        return free_slots[:6]

    def create_booking(
        self,
        payload: dict[str, Any],
        allow_conflict: bool = False,
    ) -> tuple[BookingRequest, list[str]]:
        """Validate, check conflicts, and persist a new booking request."""
        enriched = dict(payload)
        if not enriched.get("booking_id"):
            enriched["booking_id"] = self.next_booking_id()

        booking, warnings = validate_booking_payload(enriched, self.rooms_by_id)

        if self.get_booking(booking.booking_id) is not None:
            raise ValidationError(f"Booking ID '{booking.booking_id}' already exists.")

        if booking.date in self.holidays:
            warnings.append(
                f"Holiday notice: {booking.date} is '{self.holidays[booking.date]}'."
            )

        if booking.is_active:
            conflicts = self.detect_conflicts(
                booking.room_id,
                booking.date,
                booking.start_time,
                booking.end_time,
            )
            if conflicts and not allow_conflict:
                alt_rooms = self.suggest_alternative_rooms(
                    booking.date,
                    booking.start_time,
                    booking.end_time,
                    booking.attendees,
                    preferred_type=booking.resource_type,
                    exclude_room_id=booking.room_id,
                )
                alt_slots = self.find_available_slots(
                    booking.room_id,
                    booking.date,
                    booking.duration_minutes(),
                )
                conflict_ids = ", ".join(c.booking_id for c in conflicts)
                raise ScheduleConflictError(
                    f"Schedule conflict detected in {booking.room_id} on {booking.date} "
                    f"({booking.start_time}-{booking.end_time}) with: {conflict_ids}.",
                    conflicts=conflicts,
                    alternative_rooms=alt_rooms,
                    alternative_slots=alt_slots,
                )

        self.bookings.append(booking)
        self.save()
        return booking, warnings

    def update_status(
        self,
        booking_id: str,
        new_status: str,
        note_append: str = "",
    ) -> tuple[BookingRequest, list[str]]:
        """Update a booking's status while guarding against double-booking approvals."""
        booking = self.get_booking(booking_id)
        if booking is None:
            raise ValidationError(f"Booking '{booking_id}' not found.")

        validated_status = validate_choice(new_status, VALID_STATUSES, "Status")
        warnings: list[str] = []

        if validated_status == "Approved":
            approved_conflicts = self.detect_conflicts(
                booking.room_id,
                booking.date,
                booking.start_time,
                booking.end_time,
                exclude_booking_id=booking.booking_id,
                statuses=frozenset({"Approved"}),
            )
            if approved_conflicts:
                ids = ", ".join(c.booking_id for c in approved_conflicts)
                raise ScheduleConflictError(
                    f"Cannot approve {booking.booking_id}: overlaps approved booking(s) {ids}.",
                    conflicts=approved_conflicts,
                )
            pending_conflicts = self.detect_conflicts(
                booking.room_id,
                booking.date,
                booking.start_time,
                booking.end_time,
                exclude_booking_id=booking.booking_id,
                statuses=frozenset({"Pending"}),
            )
            if pending_conflicts:
                ids = ", ".join(c.booking_id for c in pending_conflicts)
                warnings.append(
                    f"Note: Pending request(s) {ids} overlap this newly approved slot and should be reviewed."
                )

        booking.status = validated_status
        if note_append.strip():
            sep = " | " if booking.notes else ""
            booking.notes = f"{booking.notes}{sep}{note_append.strip()}"[:240]
        self.save()
        return booking, warnings

    def reschedule_booking(
        self,
        booking_id: str,
        new_room_id: str,
        new_date: str,
        new_start: str,
        new_end: str,
    ) -> tuple[BookingRequest, list[str]]:
        """Move an existing booking to a validated, conflict-free room/slot."""
        booking = self.get_booking(booking_id)
        if booking is None:
            raise ValidationError(f"Booking '{booking_id}' not found.")

        room_id = validate_room_id(new_room_id, self.rooms_by_id)
        room = self.rooms_by_id[room_id]
        if booking.attendees > room.capacity:
            raise ValidationError(
                f"Attendee count ({booking.attendees}) exceeds {room_id} capacity ({room.capacity})."
            )
        date_str = validate_date(new_date)
        start_time, end_time, _ = validate_time_range(new_start, new_end)

        if booking.is_active:
            conflicts = self.detect_conflicts(
                room_id,
                date_str,
                start_time,
                end_time,
                exclude_booking_id=booking.booking_id,
            )
            if conflicts:
                raise ScheduleConflictError(
                    f"Reschedule conflict in {room_id} on {date_str} ({start_time}-{end_time}).",
                    conflicts=conflicts,
                    alternative_rooms=self.suggest_alternative_rooms(
                        date_str, start_time, end_time, booking.attendees, exclude_room_id=room_id
                    ),
                    alternative_slots=self.find_available_slots(
                        room_id, date_str, _to_minutes(end_time) - _to_minutes(start_time)
                    ),
                )

        booking.room_id = room_id
        booking.resource_type = room.resource_type
        booking.date = date_str
        booking.start_time = start_time
        booking.end_time = end_time
        self.save()

        warnings: list[str] = []
        if date_str in self.holidays:
            warnings.append(f"Holiday notice: {date_str} is '{self.holidays[date_str]}'.")
        return booking, warnings

    def delete_booking(self, booking_id: str) -> BookingRequest:
        """Permanently remove a booking record by ID."""
        booking = self.get_booking(booking_id)
        if booking is None:
            raise ValidationError(f"Booking '{booking_id}' not found.")
        self.bookings = [b for b in self.bookings if b.booking_id != booking.booking_id]
        self.save()
        return booking

    def find_all_schedule_conflicts(self) -> list[tuple[BookingRequest, BookingRequest]]:
        """Return every overlapping pair among active (Pending/Approved) bookings."""
        active = sorted(
            [b for b in self.bookings if b.is_active],
            key=lambda b: (b.room_id, b.date, b.start_time, b.booking_id),
        )
        pairs: list[tuple[BookingRequest, BookingRequest]] = []
        for idx, left in enumerate(active):
            for right in active[idx + 1 :]:
                if right.room_id != left.room_id or right.date != left.date:
                    break
                if times_overlap(left.start_time, left.end_time, right.start_time, right.end_time):
                    pairs.append((left, right))
        return pairs

    def search_bookings(
        self,
        keyword: str = "",
        room_id: str = "",
        resource_type: str = "",
        status: str = "",
        date_from: str = "",
        date_to: str = "",
        conflicts_only: bool = False,
    ) -> list[BookingRequest]:
        """Filter bookings by keyword, room, type, status, date range, or conflict state."""
        kw = keyword.strip().lower()
        r_filter = room_id.strip().upper()
        t_filter = resource_type.strip().lower()
        s_filter = status.strip().lower()

        conflicted_ids: set[str] = set()
        if conflicts_only:
            for left, right in self.find_all_schedule_conflicts():
                conflicted_ids.add(left.booking_id)
                conflicted_ids.add(right.booking_id)

        results: list[BookingRequest] = []
        for b in self.bookings:
            if r_filter and b.room_id != r_filter:
                continue
            if t_filter and b.resource_type.lower() != t_filter:
                continue
            if s_filter and b.status.lower() != s_filter:
                continue
            if date_from and b.date < date_from:
                continue
            if date_to and b.date > date_to:
                continue
            if conflicts_only and b.booking_id not in conflicted_ids:
                continue
            if kw:
                haystack = " ".join(
                    [
                        b.booking_id,
                        b.room_id,
                        b.title,
                        b.requester_name,
                        b.department,
                        b.notes,
                    ]
                ).lower()
                if kw not in haystack:
                    continue
            results.append(b)

        return sorted(results, key=lambda b: (b.date, b.start_time, b.room_id, b.booking_id))

    def get_threshold_warnings(self, reference_date: str | None = None) -> list[dict[str, str]]:
        """Generate automated warning flags for conflicts, overdue approvals, and anomalies."""
        ref_str = reference_date or datetime.now().strftime("%Y-%m-%d")
        ref_dt = datetime.strptime(ref_str, "%Y-%m-%d").date()
        urgent_cutoff = ref_dt + timedelta(days=2)

        warnings: list[dict[str, str]] = []

        for left, right in self.find_all_schedule_conflicts():
            warnings.append(
                {
                    "severity": "CRITICAL",
                    "category": "Schedule Conflict",
                    "booking_id": f"{left.booking_id} <-> {right.booking_id}",
                    "message": (
                        f"{left.room_id} on {left.date}: {left.booking_id} ({left.start_time}-{left.end_time}, {left.status}) "
                        f"overlaps {right.booking_id} ({right.start_time}-{right.end_time}, {right.status})."
                    ),
                }
            )

        for b in sorted(self.bookings, key=lambda item: (item.date, item.booking_id)):
            room = self.rooms_by_id.get(b.room_id)
            if b.status == "Pending":
                b_date = datetime.strptime(b.date, "%Y-%m-%d").date()
                if b_date < ref_dt:
                    warnings.append(
                        {
                            "severity": "HIGH",
                            "category": "Overdue Pending",
                            "booking_id": b.booking_id,
                            "message": f"{b.room_id} on {b.date} ({b.title}) is past-due and still Pending.",
                        }
                    )
                elif b_date <= urgent_cutoff:
                    warnings.append(
                        {
                            "severity": "HIGH",
                            "category": "Urgent Approval (<48h)",
                            "booking_id": b.booking_id,
                            "message": f"{b.room_id} on {b.date} {b.start_time} ({b.title}) needs immediate review.",
                        }
                    )

            if room and b.is_active:
                if b.attendees > room.capacity:
                    warnings.append(
                        {
                            "severity": "CRITICAL",
                            "category": "Over Capacity",
                            "booking_id": b.booking_id,
                            "message": f"{b.attendees} attendees exceed {room.room_id} max capacity ({room.capacity}).",
                        }
                    )
                elif b.attendees >= int(room.capacity * NEAR_CAPACITY_RATIO):
                    pct = round((b.attendees / room.capacity) * 100)
                    warnings.append(
                        {
                            "severity": "MEDIUM",
                            "category": "Near Capacity (>=90%)",
                            "booking_id": b.booking_id,
                            "message": f"{b.room_id} on {b.date}: {b.attendees}/{room.capacity} seats ({pct}%).",
                        }
                    )

            if b.is_active and b.duration_minutes() > LONG_DURATION_THRESHOLD_MINUTES:
                warnings.append(
                    {
                        "severity": "MEDIUM",
                        "category": "Long Duration (>4h)",
                        "booking_id": b.booking_id,
                        "message": f"{b.room_id} on {b.date} spans {b.duration_hours():.1f} hrs ({b.start_time}-{b.end_time}).",
                    }
                )

            if b.is_active and b.date in self.holidays:
                warnings.append(
                    {
                        "severity": "MEDIUM",
                        "category": "Campus Holiday",
                        "booking_id": b.booking_id,
                        "message": f"{b.date} is marked '{self.holidays[b.date]}' ({b.room_id}).",
                    }
                )

        severity_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2}
        warnings.sort(key=lambda w: (severity_rank.get(w["severity"], 9), w["booking_id"]))
        return warnings
