"""Domain models and constants for Classroom Resource Booking."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Any

VALID_RESOURCE_TYPES: tuple[str, ...] = (
    "Classroom",
    "Computer Lab",
    "Science Lab",
    "Seminar Hall",
    "Auditorium",
)

VALID_STATUSES: tuple[str, ...] = (
    "Pending",
    "Approved",
    "Rejected",
    "Cancelled",
)

ACTIVE_CONFLICT_STATUSES: frozenset[str] = frozenset({"Pending", "Approved"})

VALID_PRIORITIES: tuple[str, ...] = ("Normal", "High", "Urgent")

OPERATING_START_HOUR = 7
OPERATING_END_HOUR = 22
MIN_DURATION_MINUTES = 30
MAX_DURATION_MINUTES = 480
LONG_DURATION_THRESHOLD_MINUTES = 240
NEAR_CAPACITY_RATIO = 0.90


@dataclass
class Room:
    """Represents a bookable classroom, lab, or campus hall."""

    room_id: str
    name: str
    resource_type: str
    building: str
    capacity: int
    equipment: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Room:
        equipment = data.get("equipment", [])
        if isinstance(equipment, str):
            equipment = [item.strip() for item in equipment.split(",") if item.strip()]
        return cls(
            room_id=str(data["room_id"]).strip().upper(),
            name=str(data["name"]).strip(),
            resource_type=str(data["resource_type"]).strip(),
            building=str(data["building"]).strip(),
            capacity=int(data["capacity"]),
            equipment=[str(x).strip() for x in equipment],
        )


@dataclass
class BookingRequest:
    """Represents a booking request for a classroom or lab resource."""

    booking_id: str
    room_id: str
    resource_type: str
    title: str
    requester_name: str
    requester_email: str
    department: str
    date: str
    start_time: str
    end_time: str
    attendees: int
    status: str = "Pending"
    priority: str = "Normal"
    created_at: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))
    notes: str = ""

    @property
    def is_active(self) -> bool:
        """Whether this booking occupies the room schedule for conflict checks."""
        return self.status in ACTIVE_CONFLICT_STATUSES

    def duration_minutes(self) -> int:
        """Compute booking duration in minutes."""
        start_dt = datetime.strptime(self.start_time, "%H:%M")
        end_dt = datetime.strptime(self.end_time, "%H:%M")
        return int((end_dt - start_dt).total_seconds() // 60)

    def duration_hours(self) -> float:
        """Compute booking duration in hours."""
        return round(self.duration_minutes() / 60.0, 2)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BookingRequest:
        return cls(
            booking_id=str(data["booking_id"]).strip().upper(),
            room_id=str(data["room_id"]).strip().upper(),
            resource_type=str(data["resource_type"]).strip(),
            title=str(data["title"]).strip(),
            requester_name=str(data["requester_name"]).strip(),
            requester_email=str(data.get("requester_email", "")).strip().lower(),
            department=str(data["department"]).strip(),
            date=str(data["date"]).strip(),
            start_time=str(data["start_time"]).strip(),
            end_time=str(data["end_time"]).strip(),
            attendees=int(data["attendees"]),
            status=str(data.get("status", "Pending")).strip().title(),
            priority=str(data.get("priority", "Normal")).strip().title(),
            created_at=str(data.get("created_at") or datetime.now().isoformat(timespec="seconds")).strip(),
            notes=str(data.get("notes", "")).strip(),
        )
