"""Optional lightweight Tkinter graphical interface."""

from __future__ import annotations

from pathlib import Path

from .analytics import generate_executive_summary
from .engine import BookingEngine, ScheduleConflictError
from .exporter import export_all_reports
from .models import VALID_PRIORITIES
from .validators import ValidationError


def launch_gui(engine: BookingEngine, export_dir: Path) -> None:
    """Start the Tkinter GUI window."""
    try:
        import tkinter as tk
        from tkinter import messagebox, ttk
    except ImportError as exc:
        raise RuntimeError("Tkinter is not available in this Python environment.") from exc

    root = tk.Tk()
    root.title("Classroom Resource Booking — Campus Scheduler")
    root.geometry("1120x680")
    root.minsize(920, 560)

    style = ttk.Style()
    if "clam" in style.theme_names():
        style.theme_use("clam")

    # Header & KPI strip
    header_frame = ttk.Frame(root, padding=12)
    header_frame.pack(fill=tk.X)

    ttk.Label(
        header_frame,
        text="Classroom & Lab Resource Booking",
        font=("Segoe UI", 16, "bold"),
    ).pack(side=tk.LEFT)

    kpi_var = tk.StringVar()
    ttk.Label(header_frame, textvariable=kpi_var, font=("Segoe UI", 10)).pack(side=tk.RIGHT)

    # Filter bar
    filter_frame = ttk.LabelFrame(root, text="Search & Filters", padding=10)
    filter_frame.pack(fill=tk.X, padx=12, pady=(0, 8))

    kw_var = tk.StringVar()
    room_var = tk.StringVar(value="ALL")
    status_var = tk.StringVar(value="ALL")
    conflicts_only_var = tk.BooleanVar(value=False)

    ttk.Label(filter_frame, text="Keyword:").pack(side=tk.LEFT, padx=(0, 4))
    ttk.Entry(filter_frame, textvariable=kw_var, width=24).pack(side=tk.LEFT, padx=(0, 12))

    ttk.Label(filter_frame, text="Room:").pack(side=tk.LEFT, padx=(0, 4))
    room_choices = ["ALL"] + [r.room_id for r in engine.rooms]
    ttk.Combobox(filter_frame, textvariable=room_var, values=room_choices, state="readonly", width=11).pack(
        side=tk.LEFT, padx=(0, 12)
    )

    ttk.Label(filter_frame, text="Status:").pack(side=tk.LEFT, padx=(0, 4))
    status_choices = ["ALL", "Pending", "Approved", "Rejected", "Cancelled"]
    ttk.Combobox(filter_frame, textvariable=status_var, values=status_choices, state="readonly", width=11).pack(
        side=tk.LEFT, padx=(0, 12)
    )

    ttk.Checkbutton(
        filter_frame,
        text="Conflicts Only",
        variable=conflicts_only_var,
        command=lambda: refresh_table(),
    ).pack(side=tk.LEFT, padx=(0, 12))

    # Table
    table_frame = ttk.Frame(root, padding=(12, 0, 12, 8))
    table_frame.pack(fill=tk.BOTH, expand=True)

    columns = ("id", "date", "time", "room", "title", "requester", "dept", "pax", "status")
    tree = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="browse")

    headings = {
        "id": ("ID", 76),
        "date": ("Date", 92),
        "time": ("Time", 104),
        "room": ("Room", 78),
        "title": ("Title", 240),
        "requester": ("Requester", 150),
        "dept": ("Department", 130),
        "pax": ("Pax", 50),
        "status": ("Status", 86),
    }
    for col, (label, width) in headings.items():
        tree.heading(col, text=label)
        tree.column(col, width=width, anchor=tk.CENTER if col in {"id", "date", "time", "room", "pax", "status"} else tk.W)

    scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=tree.yview)
    tree.configure(yscrollcommand=scrollbar.set)
    tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def refresh_table() -> None:
        for row in tree.get_children():
            tree.delete(row)
        rows = engine.search_bookings(
            keyword=kw_var.get(),
            room_id="" if room_var.get() == "ALL" else room_var.get(),
            status="" if status_var.get() == "ALL" else status_var.get(),
            conflicts_only=conflicts_only_var.get(),
        )
        for b in rows:
            tree.insert(
                "",
                tk.END,
                iid=b.booking_id,
                values=(
                    b.booking_id,
                    b.date,
                    f"{b.start_time}-{b.end_time}",
                    b.room_id,
                    b.title,
                    b.requester_name,
                    b.department,
                    b.attendees,
                    b.status,
                ),
            )
        summary = generate_executive_summary(engine)
        kpi_var.set(
            f"Total: {summary['total_bookings']} | Active: {summary['active_bookings']} | "
            f"Pending: {summary['status_counts']['Pending']} | "
            f"Conflicts: {summary['conflict_count']} | "
            f"Avg Util: {summary['avg_room_utilization_pct']}%"
        )

    def reset_filters() -> None:
        kw_var.set("")
        room_var.set("ALL")
        status_var.set("ALL")
        conflicts_only_var.set(False)
        refresh_table()

    ttk.Button(filter_frame, text="Apply", command=refresh_table).pack(side=tk.LEFT, padx=(0, 6))
    ttk.Button(filter_frame, text="Reset", command=reset_filters).pack(side=tk.LEFT)

    def _selected_id() -> str | None:
        sel = tree.selection()
        if not sel:
            messagebox.showinfo("No Selection", "Select a booking row first.")
            return None
        return sel[0]

    def change_selected_status(new_status: str) -> None:
        bid = _selected_id()
        if not bid:
            return
        try:
            _, warnings = engine.update_status(bid, new_status)
            refresh_table()
            if warnings:
                messagebox.showwarning("Updated with Notices", "\n".join(warnings))
        except (ValidationError, ScheduleConflictError) as exc:
            messagebox.showerror("Status Update Blocked", str(exc))

    def show_warnings_popup() -> None:
        warnings = engine.get_threshold_warnings()
        if not warnings:
            messagebox.showinfo("Schedule Audit", "All clear! No conflicts or threshold warnings.")
            return
        lines = [f"[{w['severity']}] {w['category']} ({w['booking_id']}): {w['message']}" for w in warnings]
        messagebox.showwarning("Conflicts & Threshold Alerts", "\n\n".join(lines[:15]))

    def do_export() -> None:
        created, notes = export_all_reports(engine, export_dir)
        msg = "Exported files:\n" + "\n".join(f"- {p.name}" for p in created)
        if notes:
            msg += "\n\nNotes:\n" + "\n".join(notes)
        messagebox.showinfo("Export Complete", msg)

    def open_new_booking_dialog() -> None:
        win = tk.Toplevel(root)
        win.title("New Resource Booking")
        win.geometry("460x470")
        win.transient(root)
        win.grab_set()

        fields: dict[str, tk.StringVar] = {
            "room_id": tk.StringVar(value=engine.rooms[0].room_id if engine.rooms else "CR-101"),
            "title": tk.StringVar(),
            "requester_name": tk.StringVar(),
            "requester_email": tk.StringVar(),
            "department": tk.StringVar(),
            "date": tk.StringVar(value="2026-11-26"),
            "start_time": tk.StringVar(value="10:00"),
            "end_time": tk.StringVar(value="11:30"),
            "attendees": tk.StringVar(value="25"),
            "priority": tk.StringVar(value="Normal"),
            "notes": tk.StringVar(),
        }

        form = ttk.Frame(win, padding=14)
        form.pack(fill=tk.BOTH, expand=True)

        labels = [
            ("room_id", "Room ID"),
            ("title", "Session Title"),
            ("requester_name", "Requester Name"),
            ("requester_email", "Requester Email"),
            ("department", "Department"),
            ("date", "Date (YYYY-MM-DD)"),
            ("start_time", "Start Time (HH:MM)"),
            ("end_time", "End Time (HH:MM)"),
            ("attendees", "Attendees"),
            ("priority", "Priority"),
            ("notes", "Notes"),
        ]
        for idx, (key, label) in enumerate(labels):
            ttk.Label(form, text=label).grid(row=idx, column=0, sticky=tk.W, pady=4, padx=(0, 10))
            if key == "room_id":
                widget = ttk.Combobox(
                    form,
                    textvariable=fields[key],
                    values=[r.room_id for r in engine.rooms],
                    state="readonly",
                    width=28,
                )
            elif key == "priority":
                widget = ttk.Combobox(
                    form,
                    textvariable=fields[key],
                    values=list(VALID_PRIORITIES),
                    state="readonly",
                    width=28,
                )
            else:
                widget = ttk.Entry(form, textvariable=fields[key], width=31)
            widget.grid(row=idx, column=1, sticky=tk.EW, pady=4)

        form.columnconfigure(1, weight=1)

        def submit() -> None:
            payload = {k: v.get() for k, v in fields.items()}
            payload["status"] = "Pending"
            try:
                booking, warnings = engine.create_booking(payload)
                refresh_table()
                win.destroy()
                info = f"Created {booking.booking_id} ({booking.room_id} on {booking.date})."
                if warnings:
                    info += "\n\nWarnings:\n- " + "\n- ".join(warnings)
                messagebox.showinfo("Booking Recorded", info)
            except ScheduleConflictError as exc:
                alts = ", ".join(r.room_id for r in exc.alternative_rooms[:4]) or "None"
                slots = ", ".join(f"{s}-{e}" for s, e in exc.alternative_slots[:3]) or "None"
                messagebox.showerror(
                    "Schedule Conflict",
                    f"{exc}\n\nSuggested Alternative Rooms: {alts}\nFree Slots in Same Room: {slots}",
                )
            except ValidationError as exc:
                messagebox.showerror("Validation Error", str(exc))

        btns = ttk.Frame(form)
        btns.grid(row=len(labels), column=0, columnspan=2, pady=(14, 0), sticky=tk.E)
        ttk.Button(btns, text="Cancel", command=win.destroy).pack(side=tk.RIGHT, padx=(6, 0))
        ttk.Button(btns, text="Submit Booking", command=submit).pack(side=tk.RIGHT)

    # Bottom action bar
    action_frame = ttk.Frame(root, padding=(12, 4, 12, 12))
    action_frame.pack(fill=tk.X)

    ttk.Button(action_frame, text="+ New Booking", command=open_new_booking_dialog).pack(side=tk.LEFT, padx=(0, 8))
    ttk.Button(action_frame, text="Approve", command=lambda: change_selected_status("Approved")).pack(side=tk.LEFT, padx=(0, 6))
    ttk.Button(action_frame, text="Reject", command=lambda: change_selected_status("Rejected")).pack(side=tk.LEFT, padx=(0, 6))
    ttk.Button(action_frame, text="Cancel Booking", command=lambda: change_selected_status("Cancelled")).pack(side=tk.LEFT, padx=(0, 14))
    ttk.Button(action_frame, text="Conflicts & Alerts", command=show_warnings_popup).pack(side=tk.LEFT, padx=(0, 6))
    ttk.Button(action_frame, text="Export Reports", command=do_export).pack(side=tk.RIGHT)

    refresh_table()
    root.mainloop()
