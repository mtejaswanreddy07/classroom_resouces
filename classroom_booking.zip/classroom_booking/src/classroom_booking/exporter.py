"""Multi-format report exporter (Markdown, plain-text audit log, CSV, and HTML)."""

from __future__ import annotations

import csv
import html
from datetime import datetime
from pathlib import Path

from .analytics import export_summary_chart, generate_executive_summary
from .engine import BookingEngine


def export_markdown_report(engine: BookingEngine, output_path: Path) -> Path:
    """Export a structured Markdown executive summary and schedule report."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    summary = generate_executive_summary(engine)
    warnings = engine.get_threshold_warnings()
    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    lines: list[str] = [
        "# Classroom Resource Booking — Executive Summary Report",
        "",
        f"- **Generated:** {generated_at}",
        f"- **Total Records:** {summary['total_bookings']} ({summary['active_bookings']} active)",
        f"- **Active Booked Hours:** {summary['active_hours_booked']} hrs",
        f"- **Average Duration:** {summary['avg_duration_hours']} hrs",
        f"- **Average Attendees:** {summary['avg_attendees']}",
        f"- **Average Room Utilization:** {summary['avg_room_utilization_pct']}%",
        f"- **Approval Rate (Decided):** {summary['approval_rate_pct']}%",
        f"- **Schedule Conflicts Detected:** {summary['conflict_count']}",
        "",
        "## Status Breakdown",
        "",
        "| Status | Count |",
        "|---|---:|",
    ]
    for status, count in summary["status_counts"].items():
        lines.append(f"| {status} | {count} |")

    lines.extend(
        [
            "",
            "## Room Utilization",
            "",
            "| Room ID | Name | Type | Capacity | Active Bookings | Active Hours | Avg Fill % |",
            "|---|---|---|---:|---:|---:|---:|",
        ]
    )
    for r in summary["by_room"]:
        lines.append(
            f"| {r['room_id']} | {r['name']} | {r['resource_type']} | {r['capacity']} "
            f"| {r['active_count']} | {r['active_hours']} | {r['avg_fill_pct']}% |"
        )

    lines.extend(["", "## Threshold Warnings & Conflict Alerts", ""])
    if not warnings:
        lines.append("No active conflicts or threshold warnings detected.")
    else:
        lines.append("| Severity | Category | Booking(s) | Details |")
        lines.append("|---|---|---|---|")
        for w in warnings:
            lines.append(
                f"| {w['severity']} | {w['category']} | {w['booking_id']} | {w['message']} |"
            )

    lines.extend(
        [
            "",
            "## Chronological Booking Register",
            "",
            "| ID | Date | Time | Room | Title | Requester | Attendees | Status |",
            "|---|---|---|---|---|---|---:|---|",
        ]
    )
    for b in engine.search_bookings():
        lines.append(
            f"| {b.booking_id} | {b.date} | {b.start_time}-{b.end_time} | {b.room_id} "
            f"| {b.title} | {b.requester_name} | {b.attendees} | {b.status} |"
        )

    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return output_path


def export_audit_log(engine: BookingEngine, output_path: Path) -> Path:
    """Export a plain-text operational audit log."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    summary = generate_executive_summary(engine)
    warnings = engine.get_threshold_warnings()
    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    lines: list[str] = [
        "========================================================================",
        "CLASSROOM RESOURCE BOOKING - AUDIT & CONFLICT REPORT",
        f"Generated: {generated_at}",
        "========================================================================",
        f"Total Records      : {summary['total_bookings']}",
        f"Active Bookings    : {summary['active_bookings']}",
        f"Status Breakdown   : {summary['status_counts']}",
        f"Active Hours       : {summary['active_hours_booked']} hrs",
        f"Avg Utilization    : {summary['avg_room_utilization_pct']}%",
        f"Active Conflicts   : {summary['conflict_count']}",
        "",
        "[THRESHOLD WARNINGS & CONFLICTS]",
    ]
    if not warnings:
        lines.append("  (none)")
    else:
        for w in warnings:
            lines.append(
                f"  [{w['severity']:<8}] {w['category']} ({w['booking_id']}): {w['message']}"
            )

    lines.extend(["", "[BOOKING AUDIT TRAIL]"])
    for b in engine.search_bookings():
        lines.append(
            f"  {b.booking_id} | {b.date} {b.start_time}-{b.end_time} | {b.room_id:<7} | "
            f"{b.status:<9} | {b.attendees:>3} pax | {b.requester_name} | {b.title}"
        )

    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return output_path


def export_csv_report(engine: BookingEngine, output_path: Path) -> Path:
    """Export enriched standardized CSV report with computed duration and fill %."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "booking_id",
        "date",
        "start_time",
        "end_time",
        "duration_hours",
        "room_id",
        "resource_type",
        "title",
        "requester_name",
        "requester_email",
        "department",
        "attendees",
        "room_capacity",
        "capacity_utilization_pct",
        "status",
        "priority",
        "created_at",
        "notes",
    ]
    with output_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for b in engine.search_bookings():
            room = engine.rooms_by_id.get(b.room_id)
            cap = room.capacity if room else 0
            fill = round((b.attendees / cap) * 100.0, 1) if cap else 0.0
            row = b.to_dict()
            row["duration_hours"] = b.duration_hours()
            row["room_capacity"] = cap
            row["capacity_utilization_pct"] = fill
            writer.writerow(row)
    return output_path


def export_html_report(engine: BookingEngine, output_path: Path) -> Path:
    """Export a self-contained interactive HTML dashboard and booking report."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    summary = generate_executive_summary(engine)
    warnings = engine.get_threshold_warnings()
    conflicts = engine.find_all_schedule_conflicts()
    conflicted_ids = {b.booking_id for pair in conflicts for b in pair}
    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    status_badges = {
        "Approved": "badge-approved",
        "Pending": "badge-pending",
        "Rejected": "badge-rejected",
        "Cancelled": "badge-cancelled",
    }
    sev_badges = {
        "CRITICAL": "badge-rejected",
        "HIGH": "badge-pending",
        "MEDIUM": "badge-info",
    }

    room_rows_html = []
    for r in summary["by_room"]:
        fill = min(100.0, float(r["avg_fill_pct"]))
        room_rows_html.append(
            f"<tr>"
            f"<td><strong>{html.escape(r['room_id'])}</strong></td>"
            f"<td>{html.escape(r['name'])}</td>"
            f"<td>{html.escape(r['resource_type'])}</td>"
            f"<td class='num'>{r['capacity']}</td>"
            f"<td class='num'>{r['active_count']}</td>"
            f"<td class='num'>{r['active_hours']} hrs</td>"
            f"<td><div class='bar-wrap'><div class='bar-fill' style='width:{fill:.1f}%'></div></div>"
            f"<span class='bar-label'>{r['avg_fill_pct']}%</span></td>"
            f"</tr>"
        )

    warning_rows_html = []
    for w in warnings:
        cls = sev_badges.get(w["severity"], "badge-info")
        warning_rows_html.append(
            f"<tr>"
            f"<td><span class='badge {cls}'>{html.escape(w['severity'])}</span></td>"
            f"<td>{html.escape(w['category'])}</td>"
            f"<td><code>{html.escape(w['booking_id'])}</code></td>"
            f"<td>{html.escape(w['message'])}</td>"
            f"</tr>"
        )

    booking_rows_html = []
    for b in engine.search_bookings():
        cls = status_badges.get(b.status, "badge-cancelled")
        is_conflict = "1" if b.booking_id in conflicted_ids else "0"
        conflict_tag = " <span class='badge badge-rejected'>CONFLICT</span>" if is_conflict == "1" else ""
        booking_rows_html.append(
            f"<tr data-room='{html.escape(b.room_id)}' data-status='{html.escape(b.status)}' data-conflict='{is_conflict}'>"
            f"<td><code>{html.escape(b.booking_id)}</code></td>"
            f"<td>{html.escape(b.date)}</td>"
            f"<td>{html.escape(b.start_time)}–{html.escape(b.end_time)}</td>"
            f"<td><strong>{html.escape(b.room_id)}</strong></td>"
            f"<td>{html.escape(b.title)}{conflict_tag}</td>"
            f"<td>{html.escape(b.requester_name)}<br><small>{html.escape(b.department)}</small></td>"
            f"<td class='num'>{b.attendees}</td>"
            f"<td><span class='badge {cls}'>{html.escape(b.status)}</span></td>"
            f"</tr>"
        )

    room_options = "\n".join(
        f"<option value='{html.escape(r.room_id)}'>{html.escape(r.room_id)} — {html.escape(r.name)}</option>"
        for r in engine.rooms
    )

    warnings_section = (
        f"<table><thead><tr><th>Severity</th><th>Category</th><th>Booking(s)</th><th>Details</th></tr></thead>"
        f"<tbody>{''.join(warning_rows_html)}</tbody></table>"
        if warning_rows_html
        else "<p class='empty'>No active conflicts or threshold warnings detected.</p>"
    )

    page = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Classroom Resource Booking — Dashboard Report</title>
  <style>
    :root {{
      --bg: #f4f6fb;
      --card: #ffffff;
      --text: #182230;
      --muted: #5b6778;
      --border: #e2e8f0;
      --accent: #2563eb;
      --green-bg: #dcfce7;
      --green-fg: #166534;
      --amber-bg: #fef3c7;
      --amber-fg: #92400e;
      --red-bg: #fee2e2;
      --red-fg: #991b1b;
      --gray-bg: #e5e7eb;
      --gray-fg: #374151;
      --blue-bg: #dbeafe;
      --blue-fg: #1e40af;
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background: var(--bg);
      color: var(--text);
      line-height: 1.5;
    }}
    header {{
      background: linear-gradient(135deg, #0f172a, #1e3a8a);
      color: #fff;
      padding: 24px 32px;
    }}
    header h1 {{ margin: 0 0 6px; font-size: 1.65rem; }}
    header p {{ margin: 0; color: #cbd5e1; font-size: 0.92rem; }}
    main {{ max-width: 1200px; margin: 24px auto; padding: 0 20px 40px; }}
    .kpi-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 14px;
      margin-bottom: 24px;
    }}
    .kpi {{
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 10px;
      padding: 16px;
    }}
    .kpi .label {{ font-size: 0.8rem; color: var(--muted); text-transform: uppercase; letter-spacing: .04em; }}
    .kpi .value {{ font-size: 1.65rem; font-weight: 700; margin-top: 4px; }}
    .kpi .sub {{ font-size: 0.82rem; color: var(--muted); margin-top: 2px; }}
    section {{
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 10px;
      padding: 20px;
      margin-bottom: 22px;
      overflow-x: auto;
    }}
    section h2 {{ margin: 0 0 14px; font-size: 1.15rem; }}
    .filters {{
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      margin-bottom: 14px;
      align-items: center;
    }}
    .filters input, .filters select {{
      padding: 8px 10px;
      border: 1px solid var(--border);
      border-radius: 6px;
      font-size: 0.9rem;
    }}
    .filters input[type="search"] {{ flex: 1 1 240px; }}
    table {{ width: 100%; border-collapse: collapse; font-size: 0.9rem; }}
    th, td {{ text-align: left; padding: 9px 10px; border-bottom: 1px solid var(--border); vertical-align: middle; }}
    th {{ background: #f8fafc; color: var(--muted); font-weight: 600; font-size: 0.8rem; text-transform: uppercase; }}
    td.num, th.num {{ text-align: right; }}
    small {{ color: var(--muted); }}
    code {{ background: #f1f5f9; padding: 2px 5px; border-radius: 4px; font-size: 0.85em; }}
    .badge {{
      display: inline-block;
      padding: 2px 8px;
      border-radius: 999px;
      font-size: 0.76rem;
      font-weight: 600;
    }}
    .badge-approved {{ background: var(--green-bg); color: var(--green-fg); }}
    .badge-pending {{ background: var(--amber-bg); color: var(--amber-fg); }}
    .badge-rejected {{ background: var(--red-bg); color: var(--red-fg); }}
    .badge-cancelled {{ background: var(--gray-bg); color: var(--gray-fg); }}
    .badge-info {{ background: var(--blue-bg); color: var(--blue-fg); }}
    .bar-wrap {{
      display: inline-block;
      width: 90px;
      height: 8px;
      background: #e2e8f0;
      border-radius: 999px;
      overflow: hidden;
      vertical-align: middle;
      margin-right: 8px;
    }}
    .bar-fill {{ height: 100%; background: var(--accent); }}
    .bar-label {{ font-size: 0.84rem; color: var(--muted); }}
    .empty {{ color: var(--muted); font-style: italic; }}
  </style>
</head>
<body>
  <header>
    <h1>Classroom Resource Booking — Executive Dashboard</h1>
    <p>StudentLife Hack Project #22 &bull; Generated {html.escape(generated_at)}</p>
  </header>
  <main>
    <div class="kpi-grid">
      <div class="kpi"><div class="label">Total Bookings</div><div class="value">{summary['total_bookings']}</div><div class="sub">{summary['active_bookings']} active</div></div>
      <div class="kpi"><div class="label">Approved / Pending</div><div class="value">{summary['status_counts']['Approved']} / {summary['status_counts']['Pending']}</div><div class="sub">{summary['approval_rate_pct']}% approval rate</div></div>
      <div class="kpi"><div class="label">Active Booked Hours</div><div class="value">{summary['active_hours_booked']}h</div><div class="sub">Avg {summary['avg_duration_hours']}h per booking</div></div>
      <div class="kpi"><div class="label">Avg Room Utilization</div><div class="value">{summary['avg_room_utilization_pct']}%</div><div class="sub">Avg {summary['avg_attendees']} attendees</div></div>
      <div class="kpi"><div class="label">Active Conflicts</div><div class="value" style="color:{'#dc2626' if summary['conflict_count'] else '#16a34a'}">{summary['conflict_count']}</div><div class="sub">{len(warnings)} threshold alerts</div></div>
    </div>

    <section>
      <h2>Room Utilization Overview</h2>
      <table>
        <thead>
          <tr><th>Room</th><th>Name</th><th>Type</th><th class="num">Capacity</th><th class="num">Active</th><th class="num">Hours</th><th>Avg Fill</th></tr>
        </thead>
        <tbody>
          {''.join(room_rows_html)}
        </tbody>
      </table>
    </section>

    <section>
      <h2>Threshold Warnings &amp; Conflict Alerts ({len(warnings)})</h2>
      {warnings_section}
    </section>

    <section>
      <h2>Booking Register (<span id="visibleCount">{summary['total_bookings']}</span>)</h2>
      <div class="filters">
        <input type="search" id="searchBox" placeholder="Search ID, title, requester, department..." />
        <select id="roomFilter">
          <option value="">All Rooms</option>
          {room_options}
        </select>
        <select id="statusFilter">
          <option value="">All Statuses</option>
          <option value="Approved">Approved</option>
          <option value="Pending">Pending</option>
          <option value="Rejected">Rejected</option>
          <option value="Cancelled">Cancelled</option>
        </select>
        <label><input type="checkbox" id="conflictOnly" /> Conflicts Only</label>
      </div>
      <table id="bookingTable">
        <thead>
          <tr><th>ID</th><th>Date</th><th>Time</th><th>Room</th><th>Title</th><th>Requester</th><th class="num">Pax</th><th>Status</th></tr>
        </thead>
        <tbody>
          {''.join(booking_rows_html)}
        </tbody>
      </table>
    </section>
  </main>
  <script>
    const searchBox = document.getElementById("searchBox");
    const roomFilter = document.getElementById("roomFilter");
    const statusFilter = document.getElementById("statusFilter");
    const conflictOnly = document.getElementById("conflictOnly");
    const rows = Array.from(document.querySelectorAll("#bookingTable tbody tr"));
    const countEl = document.getElementById("visibleCount");

    function applyFilters() {{
      const kw = searchBox.value.trim().toLowerCase();
      const rm = roomFilter.value;
      const st = statusFilter.value;
      const cf = conflictOnly.checked;
      let shown = 0;
      for (const row of rows) {{
        const matchKw = !kw || row.textContent.toLowerCase().includes(kw);
        const matchRoom = !rm || row.dataset.room === rm;
        const matchStatus = !st || row.dataset.status === st;
        const matchConflict = !cf || row.dataset.conflict === "1";
        const visible = matchKw && matchRoom && matchStatus && matchConflict;
        row.style.display = visible ? "" : "none";
        if (visible) shown++;
      }}
      countEl.textContent = shown;
    }}

    searchBox.addEventListener("input", applyFilters);
    roomFilter.addEventListener("change", applyFilters);
    statusFilter.addEventListener("change", applyFilters);
    conflictOnly.addEventListener("change", applyFilters);
  </script>
</body>
</html>
"""
    output_path.write_text(page, encoding="utf-8")
    return output_path


def export_all_reports(engine: BookingEngine, export_dir: Path) -> tuple[list[Path], list[str]]:
    """Generate Markdown, Audit Log, CSV, HTML dashboard, and optional PNG chart."""
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    export_dir.mkdir(parents=True, exist_ok=True)

    md_path = export_markdown_report(engine, export_dir / f"summary_report_{stamp}.md")
    txt_path = export_audit_log(engine, export_dir / f"audit_log_{stamp}.txt")
    csv_path = export_csv_report(engine, export_dir / f"bookings_report_{stamp}.csv")
    html_path = export_html_report(engine, export_dir / f"dashboard_report_{stamp}.html")
    created = [md_path, txt_path, csv_path, html_path]
    notes: list[str] = []

    summary = generate_executive_summary(engine)
    chart_ok, chart_msg = export_summary_chart(summary, export_dir / f"analytics_chart_{stamp}.png")
    if chart_ok:
        created.append(export_dir / f"analytics_chart_{stamp}.png")
    else:
        notes.append(chart_msg)

    return created, notes
