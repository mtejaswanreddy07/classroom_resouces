"""Local JSON & CSV persistence with defensive corruption recovery."""

from __future__ import annotations

import csv
import json
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any

from .models import BookingRequest, Room
from .seed_data import DEFAULT_HOLIDAYS, get_default_bookings, get_default_rooms

BOOKING_CSV_FIELDS: tuple[str, ...] = (
    "booking_id",
    "room_id",
    "resource_type",
    "title",
    "requester_name",
    "requester_email",
    "department",
    "date",
    "start_time",
    "end_time",
    "attendees",
    "status",
    "priority",
    "created_at",
    "notes",
)


class DataStore:
    """Manages persistent JSON and CSV storage for rooms, bookings, and holiday cache."""

    def __init__(self, data_dir: Path) -> None:
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.rooms_path = self.data_dir / "rooms.json"
        self.bookings_json_path = self.data_dir / "bookings.json"
        self.bookings_csv_path = self.data_dir / "bookings.csv"
        self.holidays_path = self.data_dir / "holidays_cache.json"
        self.startup_notices: list[str] = []

    def _atomic_write_text(self, target: Path, content: str) -> None:
        """Write text safely via a temporary file before replacing target."""
        tmp_path = target.with_suffix(target.suffix + ".tmp")
        tmp_path.write_text(content, encoding="utf-8")
        tmp_path.replace(target)

    def _backup_corrupted(self, path: Path) -> Path:
        """Preserve corrupted storage file for inspection before resetting."""
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup = path.with_name(f"{path.name}.corrupt.{stamp}")
        shutil.copy2(path, backup)
        return backup

    def load_rooms(self, seed_if_missing: bool = True) -> list[Room]:
        """Load room catalog from rooms.json, seeding defaults if missing or corrupt."""
        if not self.rooms_path.exists():
            rooms = get_default_rooms() if seed_if_missing else []
            self.save_rooms(rooms)
            self.startup_notices.append("Initialized default room catalog (rooms.json).")
            return rooms

        try:
            raw = json.loads(self.rooms_path.read_text(encoding="utf-8"))
            if not isinstance(raw, list):
                raise ValueError("rooms.json root must be a JSON array.")
            return [Room.from_dict(item) for item in raw]
        except (json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
            backup = self._backup_corrupted(self.rooms_path)
            rooms = get_default_rooms() if seed_if_missing else []
            self.save_rooms(rooms)
            self.startup_notices.append(
                f"Recovered corrupted rooms.json ({exc}). Backup saved to {backup.name}."
            )
            return rooms

    def save_rooms(self, rooms: list[Room]) -> None:
        """Persist rooms list to rooms.json."""
        payload = json.dumps([r.to_dict() for r in rooms], indent=2)
        self._atomic_write_text(self.rooms_path, payload)

    def load_bookings(self, seed_if_missing: bool = True) -> list[BookingRequest]:
        """Load bookings from JSON (or fall back to CSV) with corruption recovery."""
        if not self.bookings_json_path.exists():
            if self.bookings_csv_path.exists():
                bookings = self._read_bookings_csv(self.bookings_csv_path)
                self.save_bookings(bookings)
                self.startup_notices.append("Restored bookings.json from existing bookings.csv.")
                return bookings
            bookings = get_default_bookings() if seed_if_missing else []
            self.save_bookings(bookings)
            self.startup_notices.append("Seeded initial dataset (40 records) into bookings.json & bookings.csv.")
            return bookings

        try:
            raw = json.loads(self.bookings_json_path.read_text(encoding="utf-8"))
            if not isinstance(raw, list):
                raise ValueError("bookings.json root must be a JSON array.")
            bookings: list[BookingRequest] = []
            for idx, item in enumerate(raw):
                if not isinstance(item, dict):
                    raise ValueError(f"Entry #{idx + 1} is not a JSON object.")
                bookings.append(BookingRequest.from_dict(item))
            if not self.bookings_csv_path.exists():
                self._write_bookings_csv(bookings)
            return bookings
        except (json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
            backup = self._backup_corrupted(self.bookings_json_path)
            bookings = get_default_bookings() if seed_if_missing else []
            self.save_bookings(bookings)
            self.startup_notices.append(
                f"Recovered corrupted bookings.json ({exc}). Backup saved to {backup.name}."
            )
            return bookings

    def _read_bookings_csv(self, csv_path: Path) -> list[BookingRequest]:
        """Parse BookingRequest records from a CSV file."""
        records: list[BookingRequest] = []
        with csv_path.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            for row in reader:
                records.append(BookingRequest.from_dict(row))
        return records

    def _write_bookings_csv(self, bookings: list[BookingRequest]) -> None:
        """Serialize bookings to bookings.csv."""
        tmp_path = self.bookings_csv_path.with_suffix(".csv.tmp")
        with tmp_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=BOOKING_CSV_FIELDS)
            writer.writeheader()
            for b in bookings:
                writer.writerow(b.to_dict())
        tmp_path.replace(self.bookings_csv_path)

    def save_bookings(self, bookings: list[BookingRequest]) -> None:
        """Persist bookings synchronously to both JSON and CSV files."""
        payload = json.dumps([b.to_dict() for b in bookings], indent=2)
        self._atomic_write_text(self.bookings_json_path, payload)
        self._write_bookings_csv(bookings)

    def load_holidays(self) -> dict[str, str]:
        """Load cached campus holidays, creating cache file if absent."""
        if not self.holidays_path.exists():
            self._atomic_write_text(self.holidays_path, json.dumps(DEFAULT_HOLIDAYS, indent=2))
            return dict(DEFAULT_HOLIDAYS)
        try:
            data = json.loads(self.holidays_path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return {str(k): str(v) for k, v in data.items()}
        except (json.JSONDecodeError, OSError):
            pass
        return dict(DEFAULT_HOLIDAYS)

    def sync_holidays_remote(self, country_code: str = "IN", year: int = 2026) -> tuple[dict[str, str], str]:
        """Attempt live holiday lookup via Nager.Date API with offline cache fallback."""
        cached = self.load_holidays()
        try:
            import requests  # Optional dependency
        except ImportError:
            return cached, "requests library not installed; using local holiday cache."

        url = f"https://date.nager.at/api/v3/PublicHolidays/{year}/{country_code}"
        try:
            resp = requests.get(url, timeout=3.0)
            resp.raise_for_status()
            payload: list[dict[str, Any]] = resp.json()
            merged = dict(cached)
            for item in payload:
                date_key = str(item.get("date", "")).strip()
                name = str(item.get("localName") or item.get("name") or "").strip()
                if date_key and name:
                    merged[date_key] = name
            self._atomic_write_text(self.holidays_path, json.dumps(merged, indent=2))
            return merged, f"Synced {len(payload)} public holidays from Nager.Date API."
        except Exception as exc:
            return cached, f"Remote holiday API unavailable ({exc.__class__.__name__}); using local cache."
