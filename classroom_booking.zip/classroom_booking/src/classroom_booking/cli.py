"""Interactive terminal interface for Classroom Resource Booking."""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path
from typing import Sequence

from . import __app_name__, __version__
from .analytics import generate_executive_summary
from .engine import BookingEngine, ScheduleConflictError
from .exporter import export_all_reports, export_html_report
from .gui import launch_gui
from .importer import import_csv_dataset
from .models import VALID_PRIORITIES, VALID_RESOURCE_TYPES, VALID_STATUSES, BookingRequest
from .storage import DataStore
from .validators import (
    UserCancelled,
    ValidationError,
    prompt_validated,
    validate_choice,
    validate_date,
    validate_email,
    validate_non_empty_text,
    validate_positive_int,
    validate_room_id,
    validate_time,
    validate_time_range,
)


class Colors:
    """Minimal ANSI color helper with safe fallback."""

    def __init__(self) -> None:
        enabled = sys.stdout.isatty() and os.environ.get("NO_COLOR") is None
        if enabled and os.name == "nt":
            os.system("")  # Enable VT100 escapes on Windows consoles
        self.RESET = "\033[0m" if enabled else ""
        self.BOLD = "\033[1m" if enabled else ""
        self.DIM = "\033[2m" if enabled else ""
        self.CYAN = "\033[96m" if enabled else ""
        self.GREEN = "\033[92m" if enabled else ""
        self.YELLOW = "\033[93m" if enabled else ""
        self.RED = "\033[91m" if enabled else ""
        self.BLUE = "\033[94m" if enabled else ""


C = Colors()


def _truncate(text: str, width: int) -> str:
    if len(text) <= width:
        return text
    return text[: max(1, width - 3)] + "..."


def print_banner(engine: BookingEngine) -> None:
    """Render branded welcome screen and live status bar."""
    conflicts = len(engine.find_all_schedule_conflicts())
    pending = sum(1 for b in engine.bookings if b.status == "Pending")
    conflict_badge = (
        f"{C.RED}{conflicts} conflict(s){C.RESET}"
        if conflicts
        else f"{C.GREEN}0 conflicts{C.RESET}"
    )
    print(f"\n{C.CYAN}{C.BOLD}+----------------------------------------------------------------------+{C.RESET}")
    print(f"{C.CYAN}{C.BOLD}|  {__app_name__:<44} v{__version__:<8}  |{C.RESET}")
    print(f"{C.CYAN}{C.BOLD}|  Campus & Administration | StudentLife Hack Project #22              |{C.RESET}")
    print(f"{C.CYAN}{C.BOLD}+----------------------------------------------------------------------+{C.RESET}")
    print(
        f"  Status: {C.BOLD}{len(engine.bookings)}{C.RESET} bookings | "
        f"{C.YELLOW}{pending} pending{C.RESET} | {conflict_badge} | "
        f"{len(engine.rooms)} rooms"
    )
    for notice in engine.store.startup_notices:
        print(f"  {C.YELLOW}[Notice]{C.RESET} {notice}")
    engine.store.startup_notices.clear()


def print_rooms_table(engine: BookingEngine) -> None:
    """Display the room catalog in a fixed-width table."""
    print(f"\n  {C.BOLD}{'Room':<8} {'Name':<30} {'Type':<14} {'Cap':>4}  {'Building':<24}{C.RESET}")
    print("  " + "-" * 84)
    for r in engine.rooms:
        print(
            f"  {r.room_id:<8} {_truncate(r.name, 29):<30} {r.resource_type:<14} "
            f"{r.capacity:>4}  {_truncate(r.building, 23):<24}"
        )


def print_bookings_paginated(bookings: Sequence[BookingRequest], page_size: int = 12) -> None:
    """Display booking records in fixed-width paginated terminal tables."""
    if not bookings:
        print(f"\n  {C.YELLOW}No matching booking records found.{C.RESET}")
        return

    total = len(bookings)
    total_pages = (total + page_size - 1) // page_size
    page = 0
    while True:
        start = page * page_size
        chunk = bookings[start : start + page_size]
        print(
            f"\n  {C.BOLD}{'ID':<8} {'Date':<10} {'Time':<11} {'Room':<8} "
            f"{'Pax':>3} {'Status':<9} {'Title':<24} {'Requester':<16}{C.RESET}"
        )
        print("  " + "-" * 96)
        for b in chunk:
            status_color = {
                "Approved": C.GREEN,
                "Pending": C.YELLOW,
                "Rejected": C.RED,
                "Cancelled": C.DIM,
            }.get(b.status, "")
            print(
                f"  {b.booking_id:<8} {b.date:<10} {b.start_time}-{b.end_time} "
                f"{b.room_id:<8} {b.attendees:>3} "
                f"{status_color}{b.status:<9}{C.RESET} "
                f"{_truncate(b.title, 23):<24} {_truncate(b.requester_name, 16):<16}"
            )
        print(f"\n  Showing {start + 1}-{min(start + page_size, total)} of {total} (Page {page + 1}/{total_pages})")
        if total_pages <= 1:
            break
        nav = input("  [N]ext page, [P]rev page, or Enter to return: ").strip().lower()
        if nav == "n" and page + 1 < total_pages:
            page += 1
        elif nav == "p" and page > 0:
            page -= 1
        else:
            break


def handle_new_booking(engine: BookingEngine) -> None:
    """Interactive guided workflow for recording a new booking request."""
    print(f"\n{C.CYAN}{C.BOLD}--- Record New Classroom / Lab Booking ---{C.RESET}")
    print_rooms_table(engine)

    try:
        room_id = prompt_validated(
            "Room ID",
            lambda v: validate_room_id(v, engine.rooms_by_id),
        )
        room = engine.rooms_by_id[room_id]
        print(f"  {C.DIM}Selected: {room.name} ({room.resource_type}, max {room.capacity} seats){C.RESET}")

        title = prompt_validated(
            "Event / Session Title",
            lambda v: validate_non_empty_text(v, "Session Title", min_len=3, max_len=100),
        )
        requester_name = prompt_validated(
            "Requester Name",
            lambda v: validate_non_empty_text(v, "Requester Name", min_len=2, max_len=80),
        )
        requester_email = prompt_validated("Requester Email", validate_email)
        department = prompt_validated(
            "Department / Club",
            lambda v: validate_non_empty_text(v, "Department", min_len=2, max_len=80),
        )
        date_str = prompt_validated("Date (YYYY-MM-DD)", validate_date)

        while True:
            start_time = prompt_validated("Start Time (HH:MM, 07:00-22:00)", validate_time)
            end_time = prompt_validated("End Time (HH:MM, 07:00-22:00)", validate_time)
            try:
                start_time, end_time, _ = validate_time_range(start_time, end_time)
                break
            except ValidationError as exc:
                print(f"  {C.RED}[!] {exc}{C.RESET}")

        attendees = prompt_validated(
            f"Expected Attendees (1-{room.capacity})",
            lambda v: validate_positive_int(v, "Attendee Count", minimum=1, maximum=room.capacity),
        )
        priority = prompt_validated(
            f"Priority ({'/'.join(VALID_PRIORITIES)})",
            lambda v: validate_choice(v, VALID_PRIORITIES, "Priority"),
            default="Normal",
        )
        notes = input("  Notes (optional): ").strip()

        payload = {
            "room_id": room_id,
            "resource_type": room.resource_type,
            "title": title,
            "requester_name": requester_name,
            "requester_email": requester_email,
            "department": department,
            "date": date_str,
            "start_time": start_time,
            "end_time": end_time,
            "attendees": attendees,
            "status": "Pending",
            "priority": priority,
            "notes": notes,
        }

        while True:
            try:
                booking, warnings = engine.create_booking(payload)
                print(
                    f"\n  {C.GREEN}[OK] Recorded booking {booking.booking_id} "
                    f"({booking.room_id} on {booking.date} {booking.start_time}-{booking.end_time}).{C.RESET}"
                )
                for w in warnings:
                    print(f"  {C.YELLOW}[Warning]{C.RESET} {w}")
                return
            except ScheduleConflictError as exc:
                print(f"\n  {C.RED}[CONFLICT DETECTED]{C.RESET} {exc}")
                for c in exc.conflicts:
                    print(
                        f"    - {c.booking_id} ({c.status}): {c.start_time}-{c.end_time} | "
                        f"{c.title} by {c.requester_name}"
                    )
                if exc.alternative_rooms:
                    print(f"\n  {C.CYAN}Available alternative rooms for {date_str} {start_time}-{end_time}:{C.RESET}")
                    for alt in exc.alternative_rooms[:4]:
                        print(f"    * {alt.room_id} ({alt.name}, {alt.resource_type}, cap {alt.capacity})")
                if exc.alternative_slots:
                    slots_str = ", ".join(f"{s}-{e}" for s, e in exc.alternative_slots[:4])
                    print(f"  {C.CYAN}Free slots in {payload['room_id']} on {date_str}:{C.RESET} {slots_str}")

                print("\n  Resolution options: [R] Switch Room  [T] Change Time  [Q] Cancel Request")
                choice = input("  Choose action: ").strip().lower()
                if choice == "r":
                    new_room = prompt_validated(
                        "New Room ID",
                        lambda v: validate_room_id(v, engine.rooms_by_id),
                    )
                    r_obj = engine.rooms_by_id[new_room]
                    if int(payload["attendees"]) > r_obj.capacity:
                        print(
                            f"  {C.RED}[!] {new_room} capacity ({r_obj.capacity}) is smaller than "
                            f"{payload['attendees']} attendees.{C.RESET}"
                        )
                        continue
                    payload["room_id"] = new_room
                    payload["resource_type"] = r_obj.resource_type
                elif choice == "t":
                    new_start = prompt_validated("New Start Time (HH:MM)", validate_time)
                    new_end = prompt_validated("New End Time (HH:MM)", validate_time)
                    try:
                        ns, ne, _ = validate_time_range(new_start, new_end)
                        payload["start_time"] = ns
                        payload["end_time"] = ne
                    except ValidationError as t_exc:
                        print(f"  {C.RED}[!] {t_exc}{C.RESET}")
                else:
                    print("  Booking request discarded.")
                    return

    except UserCancelled as exc:
        print(f"  {C.YELLOW}{exc}{C.RESET}")


def handle_search(engine: BookingEngine) -> None:
    """Interactive search and filtering workflow."""
    print(f"\n{C.CYAN}{C.BOLD}--- Search & Filter Bookings ---{C.RESET}")
    print("  1. View All Bookings")
    print("  2. Filter by Keyword / Room / Type / Status / Date Range")
    print("  3. View Active Schedule Conflicts Only")
    mode = input("  Select option [1]: ").strip() or "1"

    if mode == "1":
        print_bookings_paginated(engine.search_bookings())
        return
    if mode == "3":
        print_bookings_paginated(engine.search_bookings(conflicts_only=True))
        return

    print(f"  {C.DIM}(Press Enter to skip any filter){C.RESET}")
    kw = input("  Keyword (ID, title, requester, department): ").strip()
    room_id = input("  Room ID (e.g. CR-101): ").strip().upper()
    print(f"  Types: {', '.join(VALID_RESOURCE_TYPES)}")
    r_type = input("  Resource Type: ").strip()
    print(f"  Statuses: {', '.join(VALID_STATUSES)}")
    status = input("  Status: ").strip()
    date_from = input("  From Date (YYYY-MM-DD): ").strip()
    date_to = input("  To Date (YYYY-MM-DD): ").strip()

    results = engine.search_bookings(
        keyword=kw,
        room_id=room_id,
        resource_type=r_type,
        status=status,
        date_from=date_from,
        date_to=date_to,
    )
    print_bookings_paginated(results)


def handle_manage_booking(engine: BookingEngine) -> None:
    """Approve, reject, cancel, reschedule, or delete a booking."""
    print(f"\n{C.CYAN}{C.BOLD}--- Manage Existing Booking ---{C.RESET}")
    bid = input("  Enter Booking ID (e.g. BK-1026): ").strip().upper()
    booking = engine.get_booking(bid)
    if not booking:
        print(f"  {C.RED}[!] Booking '{bid}' not found.{C.RESET}")
        return

    print(
        f"\n  Found: {C.BOLD}{booking.booking_id}{C.RESET} | {booking.title}\n"
        f"  Room : {booking.room_id} ({booking.resource_type}) | {booking.date} {booking.start_time}-{booking.end_time}\n"
        f"  By   : {booking.requester_name} ({booking.department}) | {booking.attendees} pax\n"
        f"  State: {booking.status} | Priority: {booking.priority} | Notes: {booking.notes or '-'}"
    )
    print("\n  Actions: [1] Approve  [2] Reject  [3] Cancel  [4] Reschedule  [5] Delete  [0] Back")
    action = input("  Choose action: ").strip()

    try:
        if action in {"1", "2", "3"}:
            status_map = {"1": "Approved", "2": "Rejected", "3": "Cancelled"}
            note = input("  Audit note (optional): ").strip()
            updated, warnings = engine.update_status(booking.booking_id, status_map[action], note)
            print(f"  {C.GREEN}[OK] {updated.booking_id} updated to {updated.status}.{C.RESET}")
            for w in warnings:
                print(f"  {C.YELLOW}[Notice]{C.RESET} {w}")
        elif action == "4":
            new_room = prompt_validated(
                "New Room ID",
                lambda v: validate_room_id(v, engine.rooms_by_id),
                default=booking.room_id,
            )
            new_date = prompt_validated("New Date (YYYY-MM-DD)", validate_date, default=booking.date)
            new_start = prompt_validated("New Start Time (HH:MM)", validate_time, default=booking.start_time)
            new_end = prompt_validated("New End Time (HH:MM)", validate_time, default=booking.end_time)
            updated, warnings = engine.reschedule_booking(
                booking.booking_id, new_room, new_date, new_start, new_end
            )
            print(
                f"  {C.GREEN}[OK] Rescheduled {updated.booking_id} to {updated.room_id} "
                f"on {updated.date} {updated.start_time}-{updated.end_time}.{C.RESET}"
            )
            for w in warnings:
                print(f"  {C.YELLOW}[Warning]{C.RESET} {w}")
        elif action == "5":
            confirm = input(f"  Confirm permanent delete of {booking.booking_id}? (yes/no): ").strip().lower()
            if confirm == "yes":
                engine.delete_booking(booking.booking_id)
                print(f"  {C.GREEN}[OK] Deleted {booking.booking_id}.{C.RESET}")
            else:
                print("  Deletion cancelled.")
    except (ValidationError, ScheduleConflictError, UserCancelled) as exc:
        print(f"  {C.RED}[!] {exc}{C.RESET}")


def handle_room_availability_and_audit(engine: BookingEngine) -> None:
    """Show room catalog, check free slots, and audit all conflicts."""
    print(f"\n{C.CYAN}{C.BOLD}--- Room Availability & Conflict Audit ---{C.RESET}")
    print_rooms_table(engine)

    conflicts = engine.find_all_schedule_conflicts()
    print(f"\n  {C.BOLD}Active Schedule Conflicts ({len(conflicts)}):{C.RESET}")
    if not conflicts:
        print(f"  {C.GREEN}No overlapping active bookings detected.{C.RESET}")
    else:
        for left, right in conflicts:
            print(
                f"  {C.RED}[CONFLICT]{C.RESET} {left.room_id} on {left.date}: "
                f"{left.booking_id} ({left.start_time}-{left.end_time}, {left.status}) "
                f"<-> {right.booking_id} ({right.start_time}-{right.end_time}, {right.status})"
            )

    check = input("\n  Check free slots for a room/date? (y/N): ").strip().lower()
    if check != "y":
        return
    try:
        room_id = prompt_validated("Room ID", lambda v: validate_room_id(v, engine.rooms_by_id))
        date_str = prompt_validated("Date (YYYY-MM-DD)", validate_date)
        dur = prompt_validated(
            "Desired duration in minutes (30-480)",
            lambda v: validate_positive_int(v, "Duration", minimum=30, maximum=480),
            default="60",
        )
        slots = engine.find_available_slots(room_id, date_str, dur)
        if not slots:
            print(f"  {C.YELLOW}No free {dur}-minute windows on {date_str} in {room_id}.{C.RESET}")
        else:
            print(f"  {C.GREEN}Available slots in {room_id} on {date_str}:{C.RESET}")
            for s, e in slots:
                print(f"    * {s} - {e}")
    except UserCancelled:
        pass


def print_executive_summary(engine: BookingEngine) -> None:
    """Display formatted executive analytics and threshold warnings."""
    summary = generate_executive_summary(engine)
    warnings = engine.get_threshold_warnings()

    print(f"\n{C.CYAN}{C.BOLD}================ EXECUTIVE SUMMARY & ANALYTICS ================ {C.RESET}")
    print(f"  Total Bookings       : {summary['total_bookings']} ({summary['active_bookings']} active)")
    print(
        f"  Status Breakdown     : "
        + " | ".join(f"{k}: {v}" for k, v in summary["status_counts"].items())
    )
    print(f"  Approval Rate        : {summary['approval_rate_pct']}% (of decided requests)")
    print(f"  Active Hours Booked  : {summary['active_hours_booked']} hrs (avg {summary['avg_duration_hours']} hrs/booking)")
    print(f"  Average Attendees    : {summary['avg_attendees']} | Avg Room Fill: {summary['avg_room_utilization_pct']}%")
    print(
        f"  Conflicts / Warnings : "
        f"{C.RED if summary['conflict_count'] else C.GREEN}{summary['conflict_count']} conflict(s){C.RESET} | "
        f"{C.YELLOW if warnings else C.GREEN}{len(warnings)} threshold alert(s){C.RESET}"
    )

    print(f"\n  {C.BOLD}{'Room':<8} {'Type':<14} {'Cap':>4} {'Active':>6} {'Hours':>7} {'Avg Fill':>9}{C.RESET}")
    print("  " + "-" * 54)
    for row in summary["by_room"]:
        print(
            f"  {row['room_id']:<8} {row['resource_type']:<14} {row['capacity']:>4} "
            f"{row['active_count']:>6} {row['active_hours']:>7.1f} {row['avg_fill_pct']:>8.1f}%"
        )

    if summary["peak_hours"]:
        peaks = ", ".join(f"{hr} ({cnt})" for hr, cnt in summary["peak_hours"])
        print(f"\n  Peak Start Hours     : {peaks}")
    if summary["top_departments"]:
        depts = ", ".join(f"{dept} ({cnt})" for dept, cnt in summary["top_departments"])
        print(f"  Top Departments      : {depts}")

    print(f"\n  {C.BOLD}Threshold Warning Indicators ({len(warnings)}):{C.RESET}")
    if not warnings:
        print(f"  {C.GREEN}All thresholds within normal operating bounds.{C.RESET}")
    else:
        for w in warnings[:12]:
            sev_color = {
                "CRITICAL": C.RED,
                "HIGH": C.YELLOW,
                "MEDIUM": C.CYAN,
            }.get(w["severity"], "")
            print(
                f"  {sev_color}[{w['severity']:<8}]{C.RESET} {w['category']} "
                f"({w['booking_id']}): {w['message']}"
            )
        if len(warnings) > 12:
            print(f"  ... and {len(warnings) - 12} more (export full report to view all).")


def handle_exports(engine: BookingEngine, export_dir: Path) -> None:
    """Export Markdown, TXT audit log, CSV report, and optional chart."""
    print(f"\n{C.CYAN}{C.BOLD}--- Export Multi-Format Reports ---{C.RESET}")
    created, notes = export_all_reports(engine, export_dir)
    for path in created:
        print(f"  {C.GREEN}[Saved]{C.RESET} {path}")
    for note in notes:
        print(f"  {C.DIM}[Info]{C.RESET} {note}")


def handle_bulk_import(engine: BookingEngine, data_dir: Path, export_dir: Path) -> None:
    """Run bulk CSV import with row-by-row validation and audit log."""
    print(f"\n{C.CYAN}{C.BOLD}--- Bulk CSV Dataset Import ---{C.RESET}")
    sample_csv = data_dir / "sample_legacy_import.csv"
    default_hint = str(sample_csv) if sample_csv.exists() else ""
    prompt = f"  Path to CSV file [{default_hint}]: " if default_hint else "  Path to CSV file: "
    raw_path = input(prompt).strip() or default_hint
    if not raw_path:
        print("  Cancelled.")
        return

    try:
        res = import_csv_dataset(engine, Path(raw_path), export_dir)
        print(
            f"\n  {C.GREEN}[Import Complete]{C.RESET} Processed {res.total_rows} rows: "
            f"{C.GREEN}{res.imported_count} imported{C.RESET}, "
            f"{C.YELLOW}{res.skipped_count} skipped{C.RESET}, "
            f"{res.warnings_count} warning(s)."
        )
        for line in res.row_logs:
            print(f"    {line}")
        if res.audit_log_path:
            print(f"  Audit log saved to: {res.audit_log_path}")
    except (FileNotFoundError, ValidationError, OSError) as exc:
        print(f"  {C.RED}[!] Import failed: {exc}{C.RESET}")


def handle_holiday_sync(engine: BookingEngine) -> None:
    """Sync campus holidays via HTTP API with local cache fallback."""
    print(f"\n{C.CYAN}{C.BOLD}--- Campus Holiday Calendar Sync ---{C.RESET}")
    holidays, msg = engine.store.sync_holidays_remote()
    engine.holidays = holidays
    print(f"  {C.CYAN}[Info]{C.RESET} {msg}")
    for date_str, name in sorted(holidays.items())[:10]:
        print(f"    * {date_str}: {name}")


def run_interactive_cli(engine: BookingEngine, data_dir: Path, export_dir: Path) -> None:
    """Main interactive terminal menu loop."""
    while True:
        print_banner(engine)
        print("\n  Main Menu:")
        print("    [1] Record New Booking Request")
        print("    [2] Browse & Search Bookings")
        print("    [3] Manage Booking (Approve / Reject / Reschedule / Cancel)")
        print("    [4] Room Availability & Conflict Audit")
        print("    [5] Executive Summary & Threshold Alerts")
        print("    [6] Export Reports (Markdown / Audit Log / CSV / HTML / Chart)")
        print("    [7] Bulk Import Legacy CSV")
        print("    [8] Sync Campus Holiday Calendar")
        print("    [9] Launch Graphical Interface (Tkinter GUI)")
        print("    [0] Exit")

        choice = input("\n  Enter choice [0-9]: ").strip()
        if choice == "1":
            handle_new_booking(engine)
        elif choice == "2":
            handle_search(engine)
        elif choice == "3":
            handle_manage_booking(engine)
        elif choice == "4":
            handle_room_availability_and_audit(engine)
        elif choice == "5":
            print_executive_summary(engine)
        elif choice == "6":
            handle_exports(engine, export_dir)
        elif choice == "7":
            handle_bulk_import(engine, data_dir, export_dir)
        elif choice == "8":
            handle_holiday_sync(engine)
        elif choice == "9":
            try:
                print("  Launching Tkinter GUI window...")
                launch_gui(engine, export_dir)
            except RuntimeError as exc:
                print(f"  {C.RED}[!] {exc}{C.RESET}")
        elif choice == "0":
            print("\n  Goodbye! All changes are persisted in JSON & CSV storage.\n")
            break
        else:
            print(f"  {C.YELLOW}[!] Invalid menu option '{choice}'. Please enter 0-9.{C.RESET}")


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__app_name__)
    parser.add_argument(
        "--data-dir",
        type=Path,
        default=Path.cwd() / "data",
        help="Directory for rooms.json, bookings.json, and bookings.csv",
    )
    parser.add_argument(
        "--export-dir",
        type=Path,
        default=Path.cwd() / "exports",
        help="Directory for exported reports and import audit logs",
    )
    parser.add_argument("--gui", action="store_true", help="Launch Tkinter GUI directly")
    parser.add_argument("--summary", action="store_true", help="Print executive summary and exit")
    parser.add_argument(
        "--html",
        type=Path,
        nargs="?",
        const=Path.cwd() / "dashboard.html",
        help="Generate interactive HTML dashboard report (default: ./dashboard.html) and exit",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_arg_parser()
    args = parser.parse_args(argv)
    store = DataStore(args.data_dir)
    engine = BookingEngine(store)

    if args.html is not None:
        out_path = export_html_report(engine, args.html)
        print(f"HTML dashboard generated: {out_path}")
        return 0
    if args.summary:
        print_executive_summary(engine)
        return 0
    if args.gui:
        launch_gui(engine, args.export_dir)
        return 0

    run_interactive_cli(engine, args.data_dir, args.export_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
