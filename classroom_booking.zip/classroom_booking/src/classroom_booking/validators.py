"""Defensive input validation and interactive prompt wrappers."""

from __future__ import annotations

import re
from datetime import datetime
from typing import Any, Callable, Sequence

from .models import (
    LONG_DURATION_THRESHOLD_MINUTES,
    MAX_DURATION_MINUTES,
    MIN_DURATION_MINUTES,
    NEAR_CAPACITY_RATIO,
    OPERATING_END_HOUR,
    OPERATING_START_HOUR,
    VALID_PRIORITIES,
    VALID_RESOURCE_TYPES,
    VALID_STATUSES,
    BookingRequest,
    Room,
)

EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")
ROOM_ID_RE = re.compile(r"^[A-Z]{2,8}-\d{2,4}$")
TIME_RE = re.compile(r"^\d{2}:\d{2}$")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


class ValidationError(ValueError):
    """Raised when input fails domain or schema validation."""


class UserCancelled(Exception):
    """Raised when user cancels an interactive input flow."""


def sanitize_text(value: str) -> str:
    """Collapse internal whitespace and strip leading/trailing spaces."""
    return " ".join(value.strip().split())


def validate_non_empty_text(
    value: Any,
    field_name: str,
    min_len: int = 2,
    max_len: int = 120,
) -> str:
    """Validate and sanitize non-empty text within length bounds."""
    if value is None:
        raise ValidationError(f"{field_name} cannot be blank.")
    cleaned = sanitize_text(str(value))
    if len(cleaned) < min_len:
        raise ValidationError(f"{field_name} must be at least {min_len} characters.")
    if len(cleaned) > max_len:
        raise ValidationError(f"{field_name} cannot exceed {max_len} characters.")
    return cleaned


def validate_email(value: Any) -> str:
    """Validate institutional or personal email format."""
    cleaned = sanitize_text(str(value or "")).lower()
    if not cleaned:
        raise ValidationError("Requester email cannot be blank.")
    if not EMAIL_RE.match(cleaned):
        raise ValidationError("Invalid email format (expected e.g. user@campus.edu).")
    return cleaned


def validate_date(value: Any) -> str:
    """Validate YYYY-MM-DD calendar date."""
    cleaned = sanitize_text(str(value or ""))
    if not DATE_RE.match(cleaned):
        raise ValidationError("Date must use YYYY-MM-DD format (e.g. 2026-11-28).")
    try:
        datetime.strptime(cleaned, "%Y-%m-%d")
    except ValueError as exc:
        raise ValidationError(f"Invalid calendar date '{cleaned}'.") from exc
    return cleaned


def validate_time(value: Any, check_operating_hours: bool = True) -> str:
    """Validate 24-hour HH:MM time and optional campus operating hours."""
    cleaned = sanitize_text(str(value or ""))
    if not TIME_RE.match(cleaned):
        raise ValidationError("Time must use 24-hour HH:MM format (e.g. 09:30 or 14:00).")
    try:
        parsed = datetime.strptime(cleaned, "%H:%M")
    except ValueError as exc:
        raise ValidationError(f"Invalid time '{cleaned}'.") from exc

    if check_operating_hours:
        minutes = parsed.hour * 60 + parsed.minute
        start_limit = OPERATING_START_HOUR * 60
        end_limit = OPERATING_END_HOUR * 60
        if minutes < start_limit or minutes > end_limit:
            raise ValidationError(
                f"Time must be within campus operating hours "
                f"({OPERATING_START_HOUR:02d}:00 to {OPERATING_END_HOUR:02d}:00)."
            )
    return cleaned


def validate_time_range(start_time: str, end_time: str) -> tuple[str, str, int]:
    """Validate that end_time is after start_time and within duration bounds."""
    s = validate_time(start_time)
    e = validate_time(end_time)
    s_dt = datetime.strptime(s, "%H:%M")
    e_dt = datetime.strptime(e, "%H:%M")
    duration = int((e_dt - s_dt).total_seconds() // 60)
    if duration <= 0:
        raise ValidationError("End time must be strictly after start time.")
    if duration < MIN_DURATION_MINUTES:
        raise ValidationError(f"Minimum booking duration is {MIN_DURATION_MINUTES} minutes.")
    if duration > MAX_DURATION_MINUTES:
        raise ValidationError(
            f"Maximum single booking duration is {MAX_DURATION_MINUTES // 60} hours "
            f"({MAX_DURATION_MINUTES} minutes)."
        )
    return s, e, duration


def validate_positive_int(
    value: Any,
    field_name: str,
    minimum: int = 1,
    maximum: int | None = None,
) -> int:
    """Validate integer conversion and inclusive range limits."""
    raw = sanitize_text(str(value or ""))
    if not raw:
        raise ValidationError(f"{field_name} cannot be blank.")
    try:
        parsed = int(raw)
    except ValueError as exc:
        raise ValidationError(f"{field_name} must be a whole number.") from exc
    if parsed < minimum:
        raise ValidationError(f"{field_name} must be at least {minimum}.")
    if maximum is not None and parsed > maximum:
        raise ValidationError(f"{field_name} cannot exceed {maximum}.")
    return parsed


def validate_choice(value: Any, valid_options: Sequence[str], field_name: str) -> str:
    """Match input case-insensitively against allowed options."""
    cleaned = sanitize_text(str(value or ""))
    if not cleaned:
        raise ValidationError(f"{field_name} cannot be blank.")
    lookup = {opt.lower(): opt for opt in valid_options}
    if cleaned.lower() not in lookup:
        raise ValidationError(
            f"Invalid {field_name} '{cleaned}'. Allowed: {', '.join(valid_options)}."
        )
    return lookup[cleaned.lower()]


def validate_room_id(value: Any, rooms_by_id: dict[str, Room] | None = None) -> str:
    """Validate room code format and optional membership in room catalog."""
    cleaned = sanitize_text(str(value or "")).upper()
    if not cleaned:
        raise ValidationError("Room ID cannot be blank.")
    if not ROOM_ID_RE.match(cleaned):
        raise ValidationError("Room ID must look like CR-101, LAB-204, or AUD-01.")
    if rooms_by_id is not None and cleaned not in rooms_by_id:
        known = ", ".join(sorted(rooms_by_id.keys()))
        raise ValidationError(f"Unknown Room ID '{cleaned}'. Available rooms: {known}")
    return cleaned


def validate_booking_payload(
    data: dict[str, Any],
    rooms_by_id: dict[str, Room] | None = None,
) -> tuple[BookingRequest, list[str]]:
    """Validate a raw booking dictionary and return (BookingRequest, warnings)."""
    warnings: list[str] = []

    booking_id = validate_non_empty_text(data.get("booking_id"), "Booking ID", min_len=3, max_len=24).upper()
    room_id = validate_room_id(data.get("room_id"), rooms_by_id=rooms_by_id)

    room = rooms_by_id.get(room_id) if rooms_by_id else None
    raw_type = data.get("resource_type") or (room.resource_type if room else "")
    resource_type = validate_choice(raw_type, VALID_RESOURCE_TYPES, "Resource Type")
    if room and resource_type != room.resource_type:
        raise ValidationError(
            f"Room {room_id} is a '{room.resource_type}', not '{resource_type}'."
        )

    title = validate_non_empty_text(data.get("title"), "Event / Session Title", min_len=3, max_len=100)
    requester_name = validate_non_empty_text(data.get("requester_name"), "Requester Name", min_len=2, max_len=80)
    requester_email = validate_email(data.get("requester_email"))
    department = validate_non_empty_text(data.get("department"), "Department", min_len=2, max_len=80)
    date_str = validate_date(data.get("date"))
    start_time, end_time, duration = validate_time_range(
        str(data.get("start_time", "")),
        str(data.get("end_time", "")),
    )

    max_cap = room.capacity if room else 2000
    attendees = validate_positive_int(
        data.get("attendees"),
        "Attendee Count",
        minimum=1,
        maximum=max_cap,
    )

    status = validate_choice(data.get("status", "Pending"), VALID_STATUSES, "Status")
    priority = validate_choice(data.get("priority", "Normal"), VALID_PRIORITIES, "Priority")
    notes = sanitize_text(str(data.get("notes", "")))[:240]
    created_at = sanitize_text(str(data.get("created_at", ""))) or datetime.now().isoformat(timespec="seconds")

    if room and attendees >= int(room.capacity * NEAR_CAPACITY_RATIO):
        pct = round((attendees / room.capacity) * 100)
        warnings.append(
            f"Near-capacity threshold: {attendees}/{room.capacity} seats ({pct}%) in {room.room_id}."
        )
    if duration > LONG_DURATION_THRESHOLD_MINUTES:
        warnings.append(
            f"Long-duration booking ({duration / 60:.1f} hrs exceeds {LONG_DURATION_THRESHOLD_MINUTES // 60}h threshold)."
        )

    booking = BookingRequest(
        booking_id=booking_id,
        room_id=room_id,
        resource_type=resource_type,
        title=title,
        requester_name=requester_name,
        requester_email=requester_email,
        department=department,
        date=date_str,
        start_time=start_time,
        end_time=end_time,
        attendees=attendees,
        status=status,
        priority=priority,
        created_at=created_at,
        notes=notes,
    )
    return booking, warnings


def prompt_validated(
    prompt_label: str,
    validator: Callable[[str], Any],
    default: str | None = None,
    allow_cancel: bool = True,
) -> Any:
    """Loop until the user provides valid input or cancels with 'q'/'cancel'."""
    hint = f" [{default}]" if default is not None else ""
    cancel_note = " (or 'q' to cancel)" if allow_cancel else ""
    while True:
        try:
            raw = input(f"  {prompt_label}{hint}{cancel_note}: ")
        except EOFError as exc:
            raise UserCancelled("Input stream closed.") from exc

        stripped = raw.strip()
        if allow_cancel and stripped.lower() in {"q", "quit", "cancel"}:
            raise UserCancelled("Operation cancelled by user.")
        if not stripped and default is not None:
            stripped = default
        try:
            return validator(stripped)
        except ValidationError as exc:
            print(f"  [!] Validation error: {exc}")
