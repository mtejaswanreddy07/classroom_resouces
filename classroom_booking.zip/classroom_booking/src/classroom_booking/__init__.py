"""Classroom Resource Booking package."""

__version__ = "0.1.0"
__app_name__ = "Classroom Resource Booking"
