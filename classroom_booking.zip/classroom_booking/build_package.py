"""Verify tests, seed clean data files, and build the distributable zip package."""

from __future__ import annotations

import subprocess
import sys
import zipfile
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent
SRC_DIR = ROOT_DIR / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from classroom_booking.engine import BookingEngine  # noqa: E402
from classroom_booking.exporter import export_html_report  # noqa: E402
from classroom_booking.storage import DataStore  # noqa: E402

EXCLUDE_DIRS = {"__pycache__", ".pytest_cache", ".venv", "venv", "exports", "dist", "build", ".git"}
EXCLUDE_SUFFIXES = {".pyc", ".pyo"}


def ensure_seed_data() -> None:
    """Ensure clean data/ seed files and dashboard.html exist for the package."""
    store = DataStore(ROOT_DIR / "data")
    store.load_rooms(seed_if_missing=True)
    store.load_bookings(seed_if_missing=True)
    store.load_holidays()
    engine = BookingEngine(store)
    export_html_report(engine, ROOT_DIR / "dashboard.html")


def run_tests() -> None:
    """Execute the full unit test suite before packaging."""
    proc = subprocess.run(
        [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"],
        cwd=ROOT_DIR,
        check=False,
    )
    if proc.returncode != 0:
        raise SystemExit(proc.returncode)


def create_zip_package(output_zip: Path) -> Path:
    """Package the project directory into a clean distributable zip archive."""
    output_zip.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output_zip, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(ROOT_DIR.rglob("*")):
            if path.is_dir():
                continue
            rel = path.relative_to(ROOT_DIR)
            if any(part in EXCLUDE_DIRS for part in rel.parts):
                continue
            if path.suffix in EXCLUDE_SUFFIXES or ".corrupt." in path.name:
                continue
            arcname = Path("classroom_booking") / rel
            zf.write(path, arcname.as_posix())
    return output_zip


def main() -> int:
    ensure_seed_data()
    run_tests()
    out_zip = ROOT_DIR.parent / "classroom_booking_prototype.zip"
    create_zip_package(out_zip)
    print(f"\nBuild package created successfully: {out_zip}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
