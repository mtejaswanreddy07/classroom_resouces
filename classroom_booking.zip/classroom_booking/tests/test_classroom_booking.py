"""Comprehensive test suite for Classroom Resource Booking."""

from __future__ import annotations

import shutil
import sys
import tempfile
import unittest
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
SRC_DIR = ROOT_DIR / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from classroom_booking.analytics import generate_executive_summary  # noqa: E402
from classroom_booking.cli import main as cli_main  # noqa: E402
from classroom_booking.engine import BookingEngine, ScheduleConflictError, times_overlap  # noqa: E402
from classroom_booking.exporter import export_all_reports  # noqa: E402
from classroom_booking.importer import import_csv_dataset  # noqa: E402
from classroom_booking.storage import DataStore  # noqa: E402
from classroom_booking.validators import (  # noqa: E402
    ValidationError,
    validate_date,
    validate_email,
    validate_time_range,
)


class ClassroomBookingTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp_dir = Path(tempfile.mkdtemp(prefix="crb_test_"))
        self.data_dir = self.tmp_dir / "data"
        self.export_dir = self.tmp_dir / "exports"
        self.store = DataStore(self.data_dir)
        self.engine = BookingEngine(self.store)

    def tearDown(self) -> None:
        shutil.rmtree(self.tmp_dir, ignore_errors=True)

    def test_seed_dataset_size_and_persistence_files(self) -> None:
        self.assertEqual(len(self.engine.bookings), 40)
        self.assertEqual(len(self.engine.rooms), 8)
        self.assertTrue((self.data_dir / "bookings.json").exists())
        self.assertTrue((self.data_dir / "bookings.csv").exists())
        self.assertTrue((self.data_dir / "rooms.json").exists())

    def test_times_overlap_boundary_behavior(self) -> None:
        self.assertFalse(times_overlap("09:00", "10:30", "10:30", "12:00"))
        self.assertTrue(times_overlap("09:00", "10:30", "10:15", "11:30"))
        self.assertTrue(times_overlap("10:00", "12:00", "10:30", "11:00"))

    def test_validators_reject_invalid_inputs(self) -> None:
        with self.assertRaises(ValidationError):
            validate_date("2026-02-30")
        with self.assertRaises(ValidationError):
            validate_email("not-an-email")
        with self.assertRaises(ValidationError):
            validate_time_range("14:00", "13:00")
        with self.assertRaises(ValidationError):
            validate_time_range("10:00", "10:15")
        with self.assertRaises(ValidationError):
            validate_time_range("06:30", "08:00")

    def test_create_booking_persists_and_blocks_over_capacity(self) -> None:
        payload = {
            "room_id": "CR-102",
            "title": "Compiler Design Seminar",
            "requester_name": "Dr. Rao",
            "requester_email": "rao@campus.edu",
            "department": "Computer Science",
            "date": "2026-12-20",
            "start_time": "10:00",
            "end_time": "11:30",
            "attendees": 38,
            "status": "Pending",
            "priority": "Normal",
        }
        created, warnings = self.engine.create_booking(payload)
        self.assertEqual(created.booking_id, "BK-1041")
        self.assertTrue(any("Near-capacity" in w for w in warnings))

        # Reload from disk to prove persistence
        reloaded = BookingEngine(DataStore(self.data_dir))
        self.assertIsNotNone(reloaded.get_booking("BK-1041"))

        # Over capacity must fail
        over_cap = dict(payload)
        over_cap["start_time"] = "14:00"
        over_cap["end_time"] = "15:00"
        over_cap["attendees"] = 99
        with self.assertRaises(ValidationError):
            self.engine.create_booking(over_cap)

    def test_conflict_detection_suggests_alternatives(self) -> None:
        # Collides with BK-1001 in CR-101 on 2026-11-25 09:00-10:30
        payload = {
            "room_id": "CR-101",
            "title": "Overlapping Physics Talk",
            "requester_name": "Dr. Sen",
            "requester_email": "sen@campus.edu",
            "department": "Physics",
            "date": "2026-11-25",
            "start_time": "09:30",
            "end_time": "10:30",
            "attendees": 30,
        }
        with self.assertRaises(ScheduleConflictError) as ctx:
            self.engine.create_booking(payload)
        self.assertTrue(len(ctx.exception.conflicts) >= 1)
        self.assertTrue(len(ctx.exception.alternative_rooms) >= 1)
        self.assertTrue(len(ctx.exception.alternative_slots) >= 1)

    def test_corrupted_json_recovery(self) -> None:
        (self.data_dir / "bookings.json").write_text("{corrupt json", encoding="utf-8")
        recovered_store = DataStore(self.data_dir)
        recovered_bookings = recovered_store.load_bookings()
        self.assertEqual(len(recovered_bookings), 40)
        backups = list(self.data_dir.glob("bookings.json.corrupt.*"))
        self.assertEqual(len(backups), 1)
        self.assertTrue(any("Recovered corrupted bookings.json" in n for n in recovered_store.startup_notices))

    def test_approve_blocked_by_existing_approved_conflict(self) -> None:
        # BK-1028 is Pending on CR-101 2026-11-25 09:30-11:00 (overlaps Approved BK-1001/1002)
        with self.assertRaises(ScheduleConflictError):
            self.engine.update_status("BK-1028", "Approved")

    def test_search_summary_and_exports(self) -> None:
        summary = generate_executive_summary(self.engine)
        self.assertEqual(summary["total_bookings"], 40)
        self.assertGreaterEqual(summary["conflict_count"], 1)

        conflicts = self.engine.search_bookings(conflicts_only=True)
        self.assertGreaterEqual(len(conflicts), 2)

        created, _ = export_all_reports(self.engine, self.export_dir)
        self.assertGreaterEqual(len(created), 4)
        suffixes = {p.suffix for p in created}
        self.assertTrue({".md", ".txt", ".csv", ".html"}.issubset(suffixes))
        for path in created:
            self.assertTrue(path.exists())

    def test_cli_html_flag(self) -> None:
        html_out = self.export_dir / "dashboard.html"
        code = cli_main(["--data-dir", str(self.data_dir), "--html", str(html_out)])
        self.assertEqual(code, 0)
        self.assertTrue(html_out.exists())
        content = html_out.read_text(encoding="utf-8")
        self.assertIn("Classroom Resource Booking", content)
        self.assertIn("BK-1001", content)

    def test_bulk_csv_import_handles_mixed_rows(self) -> None:
        sample_csv = ROOT_DIR / "data" / "sample_legacy_import.csv"
        res = import_csv_dataset(self.engine, sample_csv, self.export_dir)
        self.assertEqual(res.total_rows, 7)
        self.assertEqual(res.imported_count, 4)
        self.assertEqual(res.skipped_count, 3)
        self.assertIsNotNone(res.audit_log_path)
        self.assertTrue(res.audit_log_path.exists())

    def test_cli_summary_flag(self) -> None:
        code = cli_main(["--data-dir", str(self.data_dir), "--summary"])
        self.assertEqual(code, 0)


if __name__ == "__main__":
    unittest.main()
